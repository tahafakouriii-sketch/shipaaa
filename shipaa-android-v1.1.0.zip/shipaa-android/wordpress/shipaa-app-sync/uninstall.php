<?php
// Removes only this plugin's data: the per-user watch positions it stored.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}
delete_metadata('user', 0, 'shipaa_app_progress', '', true);
