// Runs the real bridge.js inside pages built from the Studiare 13.4 templates (jsdom) and checks its contract.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const BRIDGE = fs.readFileSync(path.join(__dirname, '../../app/src/main/assets/bridge.js'), 'utf8');
const TOKENS = ':root{--shp-primary:#136B4B;}';

// Markup copied from studiare/inc/studi_lessons.php (sc_get_lessons_for_product + render_lesson_media).
const lesson = (n, title, src, extra = '') => `
  <div class="course-lesson">
    <div class="course-panel-heading"><div class="panel-heading-left">
      <div class="course-lesson-icon"><span class="lesson-number">${n}</span></div>
      <div class="title"><div class="title-inner">
        <h4>${title} <span class="badge-item video">ویدیو</span></h4>
        <a class="video-lesson-preview preview-button" href="https://www.aparat.com/v/x"><i class="fal fa-play-circle"></i>پیش‌نمایش</a>
      </div><p class="subtitle">زیرعنوان ${n}</p></div>
    </div></div>
    <div class="panel-content"><div class="panel-content-inner">
      ${src ? `<div class='sc_le_vi_au'><br><video class='studi_lesson_video scplayer scplayer--full-ui scplayer--video scplayer--html5' preload='none' style='width:100%' controlsList='nodownload' data-id='video_${n}'><source src='${src}' type='video/mp4'></video><br></div>` : ''}
      ${extra}
    </div></div>
  </div>`;

const COURSE_PAGE = `<!doctype html><html lang="fa" dir="rtl"><head><title>دوره بازگشت به قدرت – شیپا</title>
<meta property="og:image" content="https://shipaa.ir/wp-content/uploads/course.jpg">
<meta name="shipaa-app-sync" content="abc123def4"></head>
<body class="product-template-default single single-product postid-777" style="font-family: IRANYekan, Tahoma">
  <header><button class="menu-toggle" aria-expanded="false" aria-controls="m">منو</button></header>
  <div class="mobile-menu" id="m"><a class="close">×</a></div>
  <h1 class="product_title entry-title">دوره بازگشت به قدرت</h1>
  <div class="course-content-header flex"><div class="sc_before_title_icon"></div><h3 class="course-content-title">محتوای دوره</h3></div>
  <div class="course-summary"><div class="sc-course-curriculum-info"><li>۲ فصل</li></div></div>
  <div class="course-section" data-open="">
    <div data-id="s1" class="sc-course-lesson-toggle-wrapper"><h5 class="course-section-title">
      <span class="chapterholder"><span class="scchapturetitle">فصل</span><span class="scchapturenumber">۱</span></span> مقدمات
    </h5><div class="sc-course-lesson-toggle"><i class="fal fa-chevron-down"></i></div></div>
    <div class="panel-group" style="display:none;">
      ${lesson(1, 'جلسه اول: مقدمه', 'https://dl.shipaa.ir/courses/q/01.mp4')}
      ${lesson(2, 'جلسه دوم', 'https://dl.shipaa.ir/courses/q/02.mp4')}
      <div class="course-lesson"><div class="course-panel-heading scquiz"><div class="panel-heading-left">
        <div class="title"><h4>آزمون فصل اول <span class="badge-item quiz">آزمون</span></h4></div></div></div>
        <div class="panel-content scquiz"><div class="panel-content-inner"></div></div></div>
    </div>
  </div>
  <div class="course-section" data-open="">
    <div data-id="s2" class="sc-course-lesson-toggle-wrapper"><h5 class="course-section-title">
      <span class="chapterholder"><span class="scchapturetitle">فصل</span><span class="scchapturenumber">۲</span></span> تمرین‌ها
    </h5></div>
    <div class="panel-group" style="display:none;">
      ${lesson(3, 'جلسه سوم (قفل)', null, '<div class="lessonaccessdenied"><span class="icon"></span>این جلسه خصوصی است</div>')}
      ${lesson(4, 'جلسه چهارم', 'https://dl.shipaa.ir/courses/q/04.mp4')}
    </div>
  </div>
  <video id="other"><source src="https://evil.example/hack.mp4"></video>
</body></html>`;

const URL0 = 'https://shipaa.ir/product/bazgasht/';

async function load(html, { url = URL0, withNative = true } = {}) {
  const dom = new JSDOM(html, { url, runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  const sent = [];
  if (withNative) w.ShipaaNative = { postMessage: (s) => sent.push(JSON.parse(s)) };
  w.__SHP_TOKENS__ = TOKENS;
  // jsdom has no layout: treat elements as visible unless display:none.
  Object.defineProperty(w.HTMLElement.prototype, 'offsetParent', {
    get() { return this.style && this.style.display === 'none' ? null : this.parentNode; },
  });
  // Injected at document start, like WebViewCompat.addDocumentStartJavaScript.
  w.eval(BRIDGE);
  if (w.document.readyState === 'loading') await new Promise((r) => w.document.addEventListener('DOMContentLoaded', r));
  return { w, doc: w.document, sent };
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const byType = (sent, t) => sent.filter((m) => m.type === t);
const SRC1 = 'https://dl.shipaa.ir/courses/q/01.mp4';
const SRC2 = 'https://dl.shipaa.ir/courses/q/02.mp4';
const SRC4 = 'https://dl.shipaa.ir/courses/q/04.mp4';

/** What Suncode Player (a Plyr fork) does on init: wraps the <video> in its own containers. */
function suncodeInit(doc) {
  doc.querySelectorAll('video.studi_lesson_video').forEach((v) => {
    const container = doc.createElement('div');
    container.className = 'scplayer scplayer--video';
    const wrapper = doc.createElement('div');
    wrapper.className = 'scplayer__video-wrapper';
    v.parentNode.insertBefore(container, v);
    container.appendChild(wrapper);
    wrapper.appendChild(v);
  });
}

test('reports lesson videos with the lesson title (not the course title)', async () => {
  const { sent } = await load(COURSE_PAGE);
  const hello = byType(sent, 'hello')[0];
  assert.equal(hello.bridgeVersion, 2);
  assert.match(hello.fontFamily, /IRANYekan/);
  const items = byType(sent, 'videos').at(-1).items;
  assert.deepEqual(items.map((v) => v.src), [SRC1, SRC2, SRC4], 'only dl.shipaa.ir lessons');
  assert.equal(items[0].title, 'جلسه اول: مقدمه', 'badge and preview link removed');
  assert.equal(items[2].title, 'جلسه چهارم');
  assert.equal(items[0].course, 'دوره بازگشت به قدرت');
  assert.equal(items[0].pageUrl, URL0);
  assert.deepEqual(byType(sent, 'syncNonce')[0], { type: 'syncNonce', nonce: 'abc123def4' });
});

test('places each bar right after the Studiare media box, outside the player', async () => {
  const { doc } = await load(COURSE_PAGE);
  const boxes = [...doc.querySelectorAll('.sc_le_vi_au')];
  assert.equal(doc.querySelectorAll('.shp-app-bar:not(.shp-app-course)').length, 3);
  boxes.forEach((box) => assert.ok(box.nextElementSibling.classList.contains('shp-app-bar')));
  const labels = [...boxes[0].nextElementSibling.querySelectorAll('button')].map((b) => b.textContent);
  assert.deepEqual(labels, ['پخش در پلیر شیپا', 'ذخیره برای آفلاین', 'کتابخانه من']);
  // Suncode Player initialises afterwards and wraps the video: bars must stay visible outside it.
  suncodeInit(doc);
  await wait(400);
  boxes.forEach((box) => {
    assert.ok(box.nextElementSibling.classList.contains('shp-app-bar'));
    assert.equal(box.querySelector('.shp-app-bar'), null, 'no bar inside the player');
  });
  assert.equal(doc.querySelectorAll('.shp-app-bar:not(.shp-app-course)').length, 3, 'no duplicates after re-wrap');
});

test('works when the player was initialised before the bridge ran', async () => {
  const dom = new JSDOM(COURSE_PAGE, { url: URL0 });
  suncodeInit(dom.window.document);
  const { doc } = await load(dom.serialize());
  doc.querySelectorAll('.sc_le_vi_au').forEach((box) => {
    assert.ok(box.nextElementSibling.classList.contains('shp-app-bar'));
    assert.equal(box.querySelector('.shp-app-bar'), null);
  });
});

test('reports the course curriculum with sections, quiz and locked lessons', async () => {
  const { sent } = await load(COURSE_PAGE);
  const c = byType(sent, 'course').at(-1);
  assert.equal(c.postId, 777);
  assert.equal(c.title, 'دوره بازگشت به قدرت');
  assert.equal(c.pageUrl, URL0);
  assert.equal(c.image, 'https://shipaa.ir/wp-content/uploads/course.jpg');
  assert.equal(c.sections.length, 2);
  const [s1, s2] = c.sections;
  assert.deepEqual([s1.title, s1.label, s1.number], ['مقدمات', 'فصل', '۱']);
  assert.equal(s1.lessons.length, 3);
  assert.deepEqual(s1.lessons[0], { title: 'جلسه اول: مقدمه', subtitle: 'زیرعنوان 1', badge: 'ویدیو', number: '1', src: SRC1, locked: false, quiz: false });
  assert.equal(s1.lessons[2].quiz, true);
  assert.equal(s1.lessons[2].title, 'آزمون فصل اول');
  assert.equal(s1.lessons[2].src, null);
  assert.equal(s2.lessons[0].locked, true);
  assert.equal(s2.lessons[0].src, null);
  assert.equal(s2.lessons[1].src, SRC4);
});

test('course bar saves all lessons and shows the course offline status', async () => {
  const { w, doc, sent } = await load(COURSE_PAGE);
  const bar = doc.querySelector('.shp-app-course');
  assert.ok(bar);
  assert.equal(doc.querySelector('.course-summary').nextElementSibling, bar, 'right above the curriculum');
  const btn = () => bar.querySelectorAll('button')[0];
  assert.equal(btn().textContent, 'ذخیره همه جلسات (۳)');
  btn().click();
  assert.deepEqual(byType(sent, 'downloadAll')[0].items.map((i) => i.src), [SRC1, SRC2, SRC4]);

  w.ShipaaApp.onNative({ type: 'state', items: [
    { src: SRC1, state: 'COMPLETED', percent: 100, label: 'آماده پخش آفلاین', tone: 'SUCCESS' },
    { src: SRC2, state: 'DOWNLOADING', percent: 30, label: 'در حال دانلود', tone: 'PROGRESS' },
  ] });
  assert.equal(btn().textContent, 'در حال ذخیره ۱ جلسه…');
  assert.ok(btn().hasAttribute('disabled'));
  assert.match(bar.querySelector('.shp-app-status').textContent, /۱ از ۳ جلسه/);

  w.ShipaaApp.onNative({ type: 'state', items: [{ src: SRC2 }] });
  assert.equal(btn().textContent, 'ذخیره بقیه جلسات (۲)');

  w.ShipaaApp.onNative({ type: 'state', items: [SRC1, SRC2, SRC4].map((src) => ({ src, state: 'COMPLETED', percent: 100, label: 'آماده', tone: 'SUCCESS' })) });
  assert.equal(btn().textContent, 'همه جلسات ذخیره شده‌اند');
  assert.match(bar.querySelector('.shp-app-status').textContent, /۳ از ۳/);
});

test('lesson buttons send play / download / library and render states', async () => {
  const { w, doc, sent } = await load(COURSE_PAGE);
  const bar = doc.querySelector('.sc_le_vi_au').nextElementSibling;
  const [play, dl, lib] = bar.querySelectorAll('button');
  play.click(); dl.click(); lib.click();
  assert.equal(byType(sent, 'play')[0].src, SRC1);
  assert.equal(byType(sent, 'play')[0].title, 'جلسه اول: مقدمه');
  assert.equal(byType(sent, 'download')[0].src, SRC1);
  assert.equal(byType(sent, 'openLibrary').length, 1);

  const dlBtn = () => bar.querySelectorAll('button')[1];
  w.ShipaaApp.onNative({ type: 'state', items: [{ src: SRC1, state: 'DOWNLOADING', percent: 45, label: 'در حال دانلود', tone: 'PROGRESS' }] });
  assert.equal(dlBtn().textContent, 'توقف دانلود ۴۵٪');
  assert.equal(bar.querySelector('.shp-app-progress > i').style.width, '45%');
  dlBtn().click();
  assert.deepEqual(byType(sent, 'pause').at(-1), { type: 'pause', src: SRC1 });
  w.ShipaaApp.onNative(JSON.stringify({ type: 'state', items: [{ src: SRC1, state: 'PAUSED', percent: 45, label: 'متوقف', tone: 'WARNING' }] }));
  assert.equal(dlBtn().textContent, 'ادامه دانلود ۴۵٪');
  dlBtn().click();
  assert.deepEqual(byType(sent, 'resume').at(-1), { type: 'resume', src: SRC1 });
  w.ShipaaApp.onNative('not json'); // must not throw
});

test('labels are inserted as text, never as HTML', async () => {
  const { w, doc } = await load(COURSE_PAGE);
  w.ShipaaApp.onNative({ type: 'state', items: [{ src: SRC1, state: 'FAILED', label: '<img src=x onerror=alert(1)>', tone: 'DANGER' }] });
  assert.equal(doc.querySelectorAll('.shp-app-bar img').length, 0);
  assert.equal(doc.querySelector('.shp-app-chip').textContent, '<img src=x onerror=alert(1)>');
});

test('settles: no endless rescans after state updates', async () => {
  const { w, sent } = await load(COURSE_PAGE);
  await wait(500);
  w.ShipaaApp.onNative({ type: 'state', items: [{ src: SRC1, state: 'DOWNLOADING', percent: 10, label: 'در حال دانلود', tone: 'PROGRESS' }] });
  await wait(800);
  const before = sent.length;
  await wait(1500);
  assert.equal(sent.length, before, 'no new messages while nothing changes');
});

test('diagnostics describe what the bridge saw', async () => {
  const { sent } = await load(COURSE_PAGE);
  const d = byType(sent, 'diag').at(-1).text;
  assert.match(d, /bridge v2/);
  assert.match(d, /videos: 4/);
  assert.match(d, /lessons\(\.course-lesson\): 5/);
  assert.match(d, /host=dl\.shipaa\.ir ext=mp4 matched=yes/);
  assert.match(d, /host=evil\.example ext=mp4 matched=no/);
});

test('course without access (no videos) gets no course bar and no course message', async () => {
  const page = COURSE_PAGE.replace(/<div class='sc_le_vi_au'>[\s\S]*?<\/div>/g, '');
  const { doc, sent } = await load(page);
  assert.equal(doc.querySelector('.shp-app-course'), null);
  // Structure is still reported; the app ignores it because no lesson is watchable.
  assert.ok(byType(sent, 'course').at(-1).sections.every((s) => s.lessons.every((l) => l.src === null)));
});

test('generic pages: players added later are detected and removed bars are cleaned up', async () => {
  const { doc, sent } = await load(`<!doctype html><body class="postid-9"><div id="host"></div></body>`);
  const box = doc.createElement('div');
  box.className = 'video-js';
  box.innerHTML = '<video><source src="https://dl.shipaa.ir/c/2.m4v?t=1"></video>';
  doc.getElementById('host').appendChild(box);
  await wait(400);
  assert.equal(box.nextElementSibling.className, 'shp-app-bar');
  assert.equal(byType(sent, 'videos').at(-1).items[0].src, 'https://dl.shipaa.ir/c/2.m4v?t=1');
  box.remove();
  await wait(400);
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 0);
  assert.deepEqual(byType(sent, 'videos').at(-1).items, []);
});

test('back closes an open menu first, otherwise reports not handled', async () => {
  const { w, doc } = await load(COURSE_PAGE);
  let closed = 0;
  doc.querySelector('.mobile-menu .close').addEventListener('click', () => { closed++; doc.querySelector('.mobile-menu').classList.remove('active'); });
  assert.equal(w.ShipaaApp.handleBack(), false);
  doc.querySelector('.mobile-menu').classList.add('active');
  assert.equal(w.ShipaaApp.handleBack(), true);
  assert.equal(closed, 1);
  assert.equal(w.ShipaaApp.handleBack(), false);
});

test('works without the native object (plain browser) and never throws', async () => {
  const { doc } = await load(COURSE_PAGE, { withNative: false });
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 4);
  doc.querySelectorAll('.shp-app-bar button').forEach((b) => b.click());
});
