# WebView JavaScript interface (fallback bridge for WebViews without WebMessageListener).
-keepclassmembers class ir.shipaa.mobile.web.ShipaaBridge$LegacyInterface {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface

# Room entities and WorkManager workers are handled by their own consumer rules.
# Enum names are persisted in the database.
-keepclassmembers enum ir.shipaa.mobile.core.download.** { *; }

# OkHttp optional platform classes.
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
