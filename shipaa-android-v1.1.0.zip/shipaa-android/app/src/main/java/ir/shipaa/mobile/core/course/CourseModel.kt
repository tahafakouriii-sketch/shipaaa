package ir.shipaa.mobile.core.course

import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import java.security.MessageDigest

/**
 * A Studiare course curriculum as shown on its product page:
 * sections (.course-section) containing lessons (.course-lesson).
 * Stored on the device so the course can be browsed offline with the site's structure.
 */
data class CourseLesson(
    val title: String,
    val subtitle: String,
    val badge: String,
    val number: String,
    /** Normalized dl.shipaa.ir video URL, or null (quiz, text lesson, locked lesson). */
    val src: String?,
    val locked: Boolean,
    val quiz: Boolean,
)

data class CourseSection(
    val title: String,
    /** "فصل" / "بخش" label and its number, as the site shows them (may be empty). */
    val label: String,
    val number: String,
    val lessons: List<CourseLesson>,
)

data class CourseInfo(
    val postId: Long?,
    val title: String,
    val pageUrl: String,
    val image: String?,
    val sections: List<CourseSection>,
    val savedAt: Long = 0L,
) {
    /** Stable identity: the course page URL without query and fragment. */
    val key: String get() = keyOf(pageUrl)

    val lessons: List<CourseLesson> get() = sections.flatMap { it.lessons }
    val videoSrcs: List<String> get() = lessons.mapNotNull { it.src }.distinct()

    fun toMap(): Map<String, Any?> = linkedMapOf(
        "postId" to postId, "title" to title, "pageUrl" to pageUrl, "image" to image, "savedAt" to savedAt,
        "sections" to sections.map { s ->
            linkedMapOf(
                "title" to s.title, "label" to s.label, "number" to s.number,
                "lessons" to s.lessons.map { l ->
                    linkedMapOf(
                        "title" to l.title, "subtitle" to l.subtitle, "badge" to l.badge, "number" to l.number,
                        "src" to l.src, "locked" to l.locked, "quiz" to l.quiz,
                    )
                },
            )
        },
    )

    companion object {
        const val MAX_SECTIONS = 100
        const val MAX_LESSONS = 600
        private const val MAX_TEXT = 300

        fun keyOf(pageUrl: String): String {
            val base = pageUrl.substringBefore('#').substringBefore('?').trimEnd('/')
            return MessageDigest.getInstance("SHA-256").digest(base.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }.take(24)
        }

        /**
         * Builds a course from decoded JSON (from bridge.js or from the device store).
         * Everything is validated: only Shipaa pages, only allowed video URLs, bounded sizes.
         */
        fun from(m: Map<*, *>, fallbackPageUrl: String?, now: Long = 0L): CourseInfo? {
            val page = (m["pageUrl"] as? String)?.takeIf(::isShipaaPage) ?: fallbackPageUrl?.takeIf(::isShipaaPage) ?: return null
            var budget = MAX_LESSONS
            val sections = (m["sections"] as? List<*>).orEmpty().take(MAX_SECTIONS).mapNotNull { raw ->
                val s = raw as? Map<*, *> ?: return@mapNotNull null
                val lessons = (s["lessons"] as? List<*>).orEmpty().mapNotNull { lr ->
                    if (budget <= 0) return@mapNotNull null
                    val l = lr as? Map<*, *> ?: return@mapNotNull null
                    val title = text(l["title"]) ?: return@mapNotNull null
                    budget--
                    CourseLesson(
                        title = title,
                        subtitle = text(l["subtitle"]) ?: "",
                        badge = text(l["badge"]) ?: "",
                        number = text(l["number"])?.take(8) ?: "",
                        src = VideoUrlPolicy.normalize(l["src"] as? String),
                        locked = l["locked"] == true,
                        quiz = l["quiz"] == true,
                    )
                }
                if (lessons.isEmpty()) null
                else CourseSection(text(s["title"]) ?: "", text(s["label"]) ?: "", text(s["number"])?.take(8) ?: "", lessons)
            }
            if (sections.isEmpty()) return null
            val postId = when (val v = m["postId"]) { is Number -> v.toLong(); is String -> v.toLongOrNull(); else -> null }?.takeIf { it > 0 }
            val savedAt = (m["savedAt"] as? Number)?.toLong()?.takeIf { it > 0 } ?: now
            return CourseInfo(
                postId = postId,
                title = text(m["title"]) ?: "دوره",
                pageUrl = page.substringBefore('#'),
                image = (m["image"] as? String)?.takeIf { it.startsWith("https://") && it.length < 2048 },
                sections = sections,
                savedAt = savedAt,
            )
        }

        private fun text(v: Any?): String? =
            (v as? String)?.replace(Regex("\\s+"), " ")?.trim()?.take(MAX_TEXT)?.takeIf { it.isNotEmpty() }

        private fun isShipaaPage(url: String): Boolean =
            url.length < 2048 && (url.startsWith("https://shipaa.ir/") || url.startsWith("https://www.shipaa.ir/"))
    }
}

/** How much of a course is available offline. */
data class CourseOfflineSummary(val videoLessons: Int, val saved: Int, val downloading: Int) {
    val complete: Boolean get() = videoLessons > 0 && saved == videoLessons
    val fraction: Float get() = if (videoLessons == 0) 0f else saved.toFloat() / videoLessons
}

object CourseOffline {
    /** @param stateOf download state for a normalized video URL, or null when not stored */
    fun summary(course: CourseInfo, stateOf: (String) -> DownloadState?): CourseOfflineSummary {
        val srcs = course.videoSrcs
        var saved = 0
        var active = 0
        for (s in srcs) {
            when (stateOf(s)) {
                DownloadState.COMPLETED -> saved++
                DownloadState.QUEUED, DownloadState.WAITING_NETWORK, DownloadState.DOWNLOADING -> active++
                else -> Unit
            }
        }
        return CourseOfflineSummary(srcs.size, saved, active)
    }
}
