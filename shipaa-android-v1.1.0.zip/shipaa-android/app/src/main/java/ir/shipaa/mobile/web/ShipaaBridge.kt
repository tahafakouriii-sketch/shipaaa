package ir.shipaa.mobile.web

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import ir.shipaa.mobile.core.bridge.BridgeMessage
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.nav.NavigationPolicy
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.data.DownloadEntity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Two-way channel between bridge.js on shipaa.ir pages and the app.
 *
 * Preferred transport is WebViewCompat.addWebMessageListener, which only exposes the object to
 * the allowed origins and tells us whether the message came from the main frame. Old WebViews
 * fall back to addJavascriptInterface with a check of the current page URL.
 */
class ShipaaBridge(
    private val webView: WebView,
    private val onMessage: (BridgeMessage) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile var currentUrl: String? = null
    private var documentStartInjection = false
    private lateinit var script: String

    @SuppressLint("JavascriptInterface", "AddJavascriptInterface")
    fun install(context: Context) {
        script = "window.__SHP_TOKENS__=" + JSONObject.quote(DesignTokens.toCss()) + ";\n" +
            context.assets.open("bridge.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(webView, OBJECT_NAME, ORIGINS) { view, message, _, isMainFrame, _ ->
                if (isMainFrame) dispatch(message.data, view.url)
            }
        } else {
            webView.addJavascriptInterface(LegacyInterface(), OBJECT_NAME)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, script, ORIGINS)
            documentStartInjection = true
        }
    }

    /** Fallback injection for WebViews without document-start scripts (idempotent script). */
    fun onPageFinished(url: String?) {
        if (!documentStartInjection && NavigationPolicy.isSitePage(url)) webView.evaluateJavascript(script, null)
    }

    /** Sends download states for the videos on the current page. */
    fun pushStates(srcs: Collection<String>, downloads: Map<String, DownloadEntity>) {
        if (srcs.isEmpty() || !NavigationPolicy.isSitePage(webView.url)) return
        val items = JSONArray()
        for (src in srcs) {
            val e = downloads[VideoUrlPolicy.keyOf(src)]
            val o = JSONObject().put("src", src)
            if (e != null) {
                val p = DownloadPresentation.of(e.stateEnum, e.errorEnum)
                o.put("state", e.stateEnum.name).put("percent", e.percent).put("label", p.label).put("tone", p.tone.name)
            }
            items.put(o)
        }
        val payload = JSONObject().put("type", "state").put("items", items).toString()
        webView.evaluateJavascript("window.ShipaaApp&&window.ShipaaApp.onNative($payload)", null)
    }

    /** Lets the page close an open menu/popup first; [done] receives true if it handled back. */
    fun handleBack(done: (Boolean) -> Unit) {
        if (!NavigationPolicy.isSitePage(webView.url)) { done(false); return }
        webView.evaluateJavascript("(window.ShipaaApp&&window.ShipaaApp.handleBack())===true") { result -> done(result == "true") }
    }

    private fun dispatch(raw: String?, pageUrl: String?) {
        if (raw == null || raw.length > MAX_MESSAGE || !NavigationPolicy.isSitePage(pageUrl)) return
        val msg = BridgeJson.parse(raw, pageUrl) ?: return
        onMessage(msg)
    }

    private inner class LegacyInterface {
        @JavascriptInterface
        fun postMessage(data: String?) {
            val url = currentUrl
            main.post { dispatch(data, url) }
        }
    }

    companion object {
        const val OBJECT_NAME = "ShipaaNative"
        val ORIGINS = setOf("https://shipaa.ir", "https://www.shipaa.ir")
        private const val MAX_MESSAGE = 200_000
    }
}

/** JSON → BridgeMessage, using only org.json (available on Android). */
object BridgeJson {
    fun parse(raw: String, pageUrl: String?): BridgeMessage? = try {
        val o = JSONObject(raw)
        BridgeMessage.from(o.optString("type", ""), toMap(o), pageUrl)
    } catch (_: Exception) {
        null
    }

    /** Decodes a JSON object into plain maps and lists (arrays capped at BridgeMessage.MAX_ITEMS). */
    fun parseObject(raw: String): Map<String, Any?>? = try { toMap(JSONObject(raw)) } catch (_: Exception) { null }

    private fun toMap(o: JSONObject): Map<String, Any?> {
        val m = HashMap<String, Any?>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            m[k] = convert(o.opt(k))
        }
        return m
    }

    private fun convert(v: Any?): Any? = when (v) {
        null, JSONObject.NULL -> null
        is JSONObject -> toMap(v)
        is JSONArray -> (0 until minOf(v.length(), BridgeMessage.MAX_ITEMS)).map { convert(v.opt(it)) }
        else -> v
    }
}
