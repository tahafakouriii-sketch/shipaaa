package ir.shipaa.mobile.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Envelope encryption: each downloaded file has its own random AES-256 key, and that key is
 * stored only in wrapped form, encrypted by a non-exportable AES-GCM key in the Android Keystore.
 */
object KeyVault {
    private const val ALIAS = "shipaa_media_master_v1"
    private const val PROVIDER = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128

    @Synchronized
    private fun masterKey(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Returns base64(iv || ciphertext+tag). */
    fun wrap(rawKey: ByteArray): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, masterKey())
        val iv = cipher.iv
        check(iv.size == IV_BYTES) { "unexpected GCM IV size ${iv.size}" }
        val sealed = cipher.doFinal(rawKey)
        return Base64.encodeToString(iv + sealed, Base64.NO_WRAP)
    }

    /** @throws java.security.GeneralSecurityException when the master key changed or data is corrupt. */
    fun unwrap(wrapped: String): ByteArray {
        val bytes = Base64.decode(wrapped, Base64.NO_WRAP)
        require(bytes.size > IV_BYTES) { "wrapped key too short" }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(TAG_BITS, bytes, 0, IV_BYTES))
        return cipher.doFinal(bytes, IV_BYTES, bytes.size - IV_BYTES)
    }

    fun encodeNonce(nonce: ByteArray): String = Base64.encodeToString(nonce, Base64.NO_WRAP)
    fun decodeNonce(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)
}
