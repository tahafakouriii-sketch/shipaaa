package ir.shipaa.mobile.download

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.download.DownloadAction
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.data.AppPrefs
import ir.shipaa.mobile.data.DownloadRepository
import java.util.concurrent.TimeUnit

/**
 * Public API for starting, pausing, resuming and deleting downloads.
 *
 * Network is checked inside the worker rather than with a WorkManager network constraint:
 * WorkManager's CONNECTED constraint requires Android's internet *validation*, which talks to
 * Google servers that are frequently unreachable from Iran, so downloads would never start.
 */
class DownloadScheduler(
    private val context: Context,
    private val repo: DownloadRepository,
    @Suppress("unused") private val prefs: AppPrefs,
) {
    private val wm: WorkManager get() = WorkManager.getInstance(context)

    suspend fun enqueue(video: VideoInfo, ownerKey: String): String {
        val (id, needsWorker) = repo.requestDownload(video, ownerKey)
        if (needsWorker) schedule(id, ExistingWorkPolicy.KEEP)
        return id
    }

    fun schedule(id: String, policy: ExistingWorkPolicy) {
        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(workDataOf(DownloadWorker.KEY_ID to id))
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            .addTag(TAG)
            .build()
        wm.enqueueUniqueWork(workName(id), policy, request)
    }

    suspend fun pause(id: String) {
        repo.transition(id, DownloadAction.PAUSE)
        wm.cancelUniqueWork(workName(id))
    }

    suspend fun resume(id: String) {
        val e = repo.transition(id, DownloadAction.RESUME) ?: return
        if (e.stateEnum.isActive) schedule(id, ExistingWorkPolicy.REPLACE)
    }

    suspend fun delete(id: String) {
        wm.cancelUniqueWork(workName(id))
        repo.delete(id)
    }

    suspend fun deleteAll(ids: Collection<String>) = ids.forEach { delete(it) }

    /** Makes sure every unfinished download has a worker (after updates, crashes or reboots). */
    suspend fun reconcile() {
        repo.all().filter { it.stateEnum.isActive }.forEach { schedule(it.id, ExistingWorkPolicy.KEEP) }
    }

    /** Called when connectivity returns: skip the remaining back-off of waiting downloads. */
    suspend fun resumeWaiting() {
        repo.all().filter { it.stateEnum == DownloadState.WAITING_NETWORK }
            .forEach { schedule(it.id, ExistingWorkPolicy.REPLACE) }
    }

    companion object {
        const val TAG = "shipaa-download"
        fun workName(id: String) = "download-$id"
    }
}
