package ir.shipaa.mobile.core.video

import java.net.URI
import java.security.MessageDigest

/**
 * Which video URLs the app may play natively or store, and how they are identified.
 * Studiare lessons on Shipaa store a direct MP4/M4V link on dl.shipaa.ir
 * (post meta lesson_data[0].lesson_video).
 */
object VideoUrlPolicy {
    val allowedHosts = setOf("dl.shipaa.ir")
    private val allowedExtensions = setOf("mp4", "m4v")
    const val MAX_URL_LENGTH = 2048

    /** Returns a canonical URL (https, lower-case host, no fragment) or null when not allowed. */
    fun normalize(raw: String?): String? {
        if (raw == null) return null
        val trimmed = raw.trim()
        if (trimmed.isEmpty() || trimmed.length > MAX_URL_LENGTH) return null
        val uri = try { URI(trimmed) } catch (_: Exception) { return null }
        if (!"https".equals(uri.scheme, ignoreCase = true)) return null
        val host = uri.host?.lowercase() ?: return null
        if (host !in allowedHosts) return null
        if (uri.userInfo != null) return null
        if (uri.port != -1 && uri.port != 443) return null
        val path = uri.rawPath ?: return null
        if (path.contains("..")) return null
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext !in allowedExtensions) return null
        val query = uri.rawQuery?.let { "?$it" } ?: ""
        return "https://$host$path$query"
    }

    fun isAllowed(raw: String?): Boolean = normalize(raw) != null

    /**
     * Stable identity of a video. The query string is ignored so that signed/cache-busting
     * parameters do not create duplicate downloads of the same file.
     */
    fun keyOf(normalizedUrl: String): String {
        val withoutQuery = normalizedUrl.substringBefore('?')
        val digest = MessageDigest.getInstance("SHA-256").digest(withoutQuery.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(32)
    }

    /** A human file stem from the URL, used only as a fallback title. */
    fun fallbackTitle(normalizedUrl: String): String =
        java.net.URLDecoder.decode(normalizedUrl.substringBefore('?').substringAfterLast('/'), "UTF-8")
            .substringBeforeLast('.')
            .replace('_', ' ').replace('-', ' ').trim()
            .ifEmpty { "ویدئو" }
}
