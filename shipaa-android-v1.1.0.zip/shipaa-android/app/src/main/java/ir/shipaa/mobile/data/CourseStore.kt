package ir.shipaa.mobile.data

import ir.shipaa.mobile.core.course.CourseInfo
import ir.shipaa.mobile.web.BridgeJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * Curricula of the courses the user opened in the app, one JSON file per account and course
 * (filesDir/courses/<ownerKey>/<courseKey>.json). Lets the offline library show each course
 * with the same sections and lessons as the site. Files, not Room, so no schema migration.
 */
class CourseStore(private val root: File, private val clock: () -> Long = System::currentTimeMillis) {
    private val cache = MutableStateFlow<Map<String, List<CourseInfo>>>(emptyMap())
    private val lock = Mutex()

    fun observe(owner: String): Flow<List<CourseInfo>> =
        cache.map { all -> all[owner].orEmpty().sortedByDescending { it.savedAt } }.onStart { ensureLoaded(owner) }

    suspend fun get(owner: String, key: String): CourseInfo? {
        ensureLoaded(owner)
        return cache.value[owner].orEmpty().firstOrNull { it.key == key }
    }

    suspend fun save(owner: String, course: CourseInfo) = withContext(Dispatchers.IO) {
        if (!safe(owner)) return@withContext
        ensureLoaded(owner)
        val stamped = course.copy(savedAt = clock())
        val dir = File(root, owner).apply { mkdirs() }
        val tmp = File(dir, "${stamped.key}.json.tmp")
        tmp.writeText(JSONObject(stamped.toMap()).toString(), Charsets.UTF_8)
        if (!tmp.renameTo(File(dir, "${stamped.key}.json"))) tmp.delete()
        lock.withLock {
            val list = cache.value[owner].orEmpty().filter { it.key != stamped.key } + stamped
            cache.value = cache.value + (owner to list)
        }
    }

    suspend fun delete(owner: String, key: String) = withContext(Dispatchers.IO) {
        if (!safe(owner)) return@withContext
        File(File(root, owner), "$key.json").delete()
        lock.withLock {
            cache.value = cache.value + (owner to cache.value[owner].orEmpty().filter { it.key != key })
        }
    }

    private suspend fun ensureLoaded(owner: String) {
        if (!safe(owner) || cache.value.containsKey(owner)) return
        val loaded = withContext(Dispatchers.IO) {
            File(root, owner).listFiles { f -> f.name.endsWith(".json") }.orEmpty().mapNotNull { f ->
                try {
                    BridgeJson.parseObject(f.readText(Charsets.UTF_8))?.let { CourseInfo.from(it, null) }
                } catch (_: Exception) {
                    null
                }
            }
        }
        lock.withLock { if (!cache.value.containsKey(owner)) cache.value = cache.value + (owner to loaded) }
    }

    private fun safe(owner: String) = owner.matches(Regex("^[0-9a-f]{8,64}$"))
}
