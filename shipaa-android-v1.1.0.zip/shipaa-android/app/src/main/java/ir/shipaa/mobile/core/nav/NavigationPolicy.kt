package ir.shipaa.mobile.core.nav

import java.net.URI

/** Decides where a link tapped inside the WebView should go. */
object NavigationPolicy {
    val siteHosts = setOf("shipaa.ir", "www.shipaa.ir")
    const val LIBRARY_FRAGMENT = "shipaa-library"
    /**
     * Iranian payment gateways and banks. Checkout must finish inside the app so the bank's
     * callback lands in the same signed-in WebView session. Matched by domain suffix.
     */
    val paymentDomains = setOf(
        "shaparak.ir", "zarinpal.com", "zibal.ir", "idpay.ir", "payping.ir", "nextpay.org", "pay.ir",
        "sep.ir", "bitpay.ir", "vandar.io", "sizpay.ir", "aqayepardakht.ir", "sadadpsp.ir", "pec.ir",
        "irankish.com", "behpardakht.com", "asanpardakht.ir", "digipay.ir", "snapppay.ir",
    )

    fun isPaymentHost(host: String?): Boolean {
        val h = host?.lowercase()?.trimEnd('.') ?: return false
        return paymentDomains.any { h == it || h.endsWith(".$it") }
    }

    private val externalSchemes = setOf("mailto", "tel", "sms", "eitaa", "tg", "whatsapp", "bale", "intent", "market")

    sealed interface Decision {
        /** Load inside the app's WebView. */
        data object InApp : Decision
        /** Open the native library of saved videos. */
        data object OpenLibrary : Decision
        /** Open the native player for a lesson video. */
        data class PlayNative(val videoUrl: String) : Decision
        /** Hand to another app (browser, messenger, dialer, payment gateway…). */
        data class External(val url: String) : Decision
        /** Do nothing (unsafe or unsupported). */
        data object Block : Decision
    }

    /**
     * @param userGesture true when the user tapped a link; false for redirects and form posts
     *        (payment gateways, bank callbacks), which must stay inside the app so the payment
     *        returns to the same signed-in session.
     * @param fromSitePage whether the WebView is currently showing a shipaa.ir page
     */
    fun decide(
        url: String?,
        isVideoFile: (String) -> Boolean = { false },
        userGesture: Boolean = true,
        fromSitePage: Boolean = true,
    ): Decision {
        if (url.isNullOrBlank()) return Decision.Block
        if (url.startsWith("shipaa://library", ignoreCase = true)) return Decision.OpenLibrary
        val uri = try { URI(url.trim()) } catch (_: Exception) { return Decision.Block }
        val scheme = uri.scheme?.lowercase() ?: return Decision.Block
        if (uri.rawFragment == LIBRARY_FRAGMENT) return Decision.OpenLibrary
        return when (scheme) {
            "https" -> when {
                isVideoFile(url) -> Decision.PlayNative(url)
                (uri.host?.lowercase() ?: "") in siteHosts -> Decision.InApp
                // Redirects, payment gateways and anything inside a gateway page stay in-app.
                !userGesture || !fromSitePage || isPaymentHost(uri.host) -> Decision.InApp
                else -> Decision.External(url)
            }
            // The site is HTTPS only; plain http links to it are upgraded, others leave the app.
            "http" -> if ((uri.host?.lowercase() ?: "") in siteHosts) Decision.InApp else Decision.External(url)
            in externalSchemes -> if (scheme == "intent") Decision.Block else Decision.External(url)
            else -> Decision.Block // javascript:, file:, content:, data: …
        }
    }

    fun isSitePage(url: String?): Boolean {
        val host = try { URI(url ?: return false).host?.lowercase() } catch (_: Exception) { null }
        return host in siteHosts
    }
}
