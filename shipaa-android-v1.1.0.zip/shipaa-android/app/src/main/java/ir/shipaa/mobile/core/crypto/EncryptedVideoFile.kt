package ir.shipaa.mobile.core.crypto

import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * An on-disk video whose bytes are AES-CTR encrypted at the same offsets as the plaintext,
 * so the file length equals the number of plaintext bytes downloaded (used for resuming).
 */
class EncryptedVideoFile(val file: File, private val cipher: CtrStreamCipher) {

    val length: Long get() = if (file.exists()) file.length() else 0L

    /** Opens an appender that continues at the current end of file. */
    fun appender(): Appender {
        file.parentFile?.mkdirs()
        return Appender(RandomAccessFile(file, "rw"), cipher)
    }

    /** Discards all stored bytes (used when the server file changed). */
    fun truncate() {
        if (file.exists()) RandomAccessFile(file, "rw").use { it.setLength(0) }
    }

    fun delete(): Boolean = !file.exists() || file.delete()

    fun reader(): Reader = Reader(RandomAccessFile(file, "r"), cipher)

    class Appender internal constructor(private val raf: RandomAccessFile, private val cipher: CtrStreamCipher) : Closeable {
        private val position0 = raf.length()
        private var position = position0
        private val session = cipher.at(position0)
        private val scratch = ByteArray(64 * 1024)

        init { raf.seek(position0) }

        val offset: Long get() = position

        /** Encrypts and writes [length] bytes of plaintext. The caller's buffer is not modified. */
        fun write(plain: ByteArray, off: Int, length: Int) {
            var done = 0
            while (done < length) {
                val n = minOf(scratch.size, length - done)
                System.arraycopy(plain, off + done, scratch, 0, n)
                session.transform(scratch, 0, n)
                raf.write(scratch, 0, n)
                done += n
                position += n
            }
        }

        /** Forces written bytes to storage so a crash loses at most the unflushed tail. */
        fun sync() { raf.fd.sync() }

        override fun close() { raf.close() }
    }

    /** Random-access decrypting reader, used by the player's DataSource. */
    class Reader internal constructor(private val raf: RandomAccessFile, private val cipher: CtrStreamCipher) : Closeable {
        val length: Long = raf.length()
        private var position = 0L
        private var session = cipher.at(0)

        fun seek(to: Long) {
            if (to < 0 || to > length) throw IOException("seek $to outside 0..$length")
            raf.seek(to)
            position = to
            session = cipher.at(to)
        }

        /** Reads and decrypts up to [len] bytes; returns -1 at end of file. */
        fun read(buffer: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (position >= length) return -1
            val n = raf.read(buffer, off, minOf(len.toLong(), length - position).toInt())
            if (n <= 0) return -1
            session.transform(buffer, off, n)
            position += n
            return n
        }

        override fun close() { raf.close() }
    }
}
