package ir.shipaa.mobile.download

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.shipaa.mobile.AppGraph
import kotlinx.coroutines.launch

/** Handles the "توقف" button on the download notification. Not exported. */
class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_PAUSE) return
        val id = intent.getStringExtra(EXTRA_ID) ?: return
        AppGraph.ensure(context)
        val pending = goAsync()
        AppGraph.scope.launch {
            try { AppGraph.scheduler.pause(id) } finally { pending.finish() }
        }
    }

    companion object {
        const val ACTION_PAUSE = "ir.shipaa.mobile.action.PAUSE_DOWNLOAD"
        const val EXTRA_ID = "id"
    }
}
