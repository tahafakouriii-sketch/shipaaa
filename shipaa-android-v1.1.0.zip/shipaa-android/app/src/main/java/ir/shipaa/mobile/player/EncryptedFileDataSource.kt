package ir.shipaa.mobile.player

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import ir.shipaa.mobile.core.crypto.EncryptedVideoFile
import java.io.IOException

/**
 * Media3 DataSource that decrypts a stored lesson on the fly with random access, so seeking
 * works and the plaintext video never touches the disk.
 */
@OptIn(UnstableApi::class)
class EncryptedFileDataSource(private val file: EncryptedVideoFile) : BaseDataSource(/* isNetwork = */ false) {

    private var reader: EncryptedVideoFile.Reader? = null
    private var uri: Uri? = null
    private var bytesRemaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val r = try {
            file.reader()
        } catch (e: IOException) {
            throw DataSourceException(e, PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND)
        }
        reader = r
        if (dataSpec.position > r.length) {
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        r.seek(dataSpec.position)
        bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            minOf(dataSpec.length, r.length - dataSpec.position)
        } else {
            r.length - dataSpec.position
        }
        opened = true
        transferStarted(dataSpec)
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT
        val r = reader ?: throw IOException("not opened")
        val n = r.read(buffer, offset, minOf(length.toLong(), bytesRemaining).toInt())
        if (n < 0) return C.RESULT_END_OF_INPUT
        bytesRemaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        try {
            reader?.close()
        } finally {
            reader = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }

    class Factory(private val file: EncryptedVideoFile) : DataSource.Factory {
        override fun createDataSource(): DataSource = EncryptedFileDataSource(file)
    }
}
