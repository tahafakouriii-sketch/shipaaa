package ir.shipaa.mobile.core.identity

import java.net.URLDecoder
import java.security.MessageDigest

/**
 * Who is signed in on shipaa.ir, derived from the WordPress `wordpress_logged_in_<hash>` cookie
 * whose value is `username|expiration|token|hmac`. The app never sends or validates the cookie;
 * the site does. This only tells stored downloads apart per account on a shared phone.
 */
data class WpIdentity(val username: String, val expiresAtEpochSec: Long) {
    /** Opaque, stable per-account key stored with downloads (the username is not stored in clear). */
    val ownerKey: String
        get() = MessageDigest.getInstance("SHA-256")
            .digest(("shipaa-owner:" + username.lowercase()).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }.take(24)

    companion object {
        private const val PREFIX = "wordpress_logged_in_"

        /** @param cookieHeader the value returned by CookieManager.getCookie("https://shipaa.ir") */
        fun fromCookieHeader(cookieHeader: String?, nowEpochSec: Long): WpIdentity? {
            if (cookieHeader.isNullOrBlank()) return null
            return cookieHeader.split(';')
                .asSequence()
                .map { it.trim() }
                .filter { it.startsWith(PREFIX) && it.contains('=') }
                .mapNotNull { parseValue(it.substringAfter('=')) }
                .filter { it.expiresAtEpochSec > nowEpochSec }
                .maxByOrNull { it.expiresAtEpochSec }
        }

        internal fun parseValue(raw: String): WpIdentity? {
            val value = try { URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { return null }
            val parts = value.split('|')
            if (parts.size < 4) return null
            val user = parts[0].trim()
            val exp = parts[1].toLongOrNull() ?: return null
            if (user.isEmpty() || user.length > 120) return null
            return WpIdentity(user, exp)
        }
    }
}
