package ir.shipaa.mobile.update

import ir.shipaa.mobile.BuildConfig
import ir.shipaa.mobile.core.update.UpdateDecision
import ir.shipaa.mobile.core.update.UpdateManifest
import ir.shipaa.mobile.core.update.UpdatePolicy
import ir.shipaa.mobile.data.AppPrefs
import ir.shipaa.mobile.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Reads the update manifest (docs/MAINTENANCE-FA.md). A missing manifest simply means "up to date". */
object UpdateChecker {
    private val minInterval = TimeUnit.HOURS.toMillis(12)

    suspend fun check(prefs: AppPrefs, force: Boolean = false): UpdateDecision = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!force && now - prefs.lastUpdateCheckAt < minInterval) return@withContext UpdateDecision.UpToDate
        val manifest = fetch() ?: return@withContext UpdateDecision.UpToDate
        prefs.lastUpdateCheckAt = now
        UpdatePolicy.decide(BuildConfig.VERSION_CODE, manifest, if (force) 0 else prefs.dismissedUpdateCode)
    }

    private fun fetch(): UpdateManifest? = try {
        val request = Request.Builder().url(BuildConfig.UPDATE_MANIFEST_URL).header("Cache-Control", "no-cache").build()
        Http.client().newCall(request).execute().use { r ->
            if (!r.isSuccessful) return null
            val text = r.body?.string()?.take(64_000) ?: return null
            val o = JSONObject(text)
            UpdateManifest(
                latestVersionCode = o.getInt("latestVersionCode"),
                minSupportedVersionCode = o.optInt("minSupportedVersionCode", 0),
                versionName = o.optString("versionName", ""),
                downloadUrl = o.optString("downloadUrl", ""),
                notes = o.optString("notes", "").take(1000),
            )
        }
    } catch (_: Exception) {
        null
    }
}
