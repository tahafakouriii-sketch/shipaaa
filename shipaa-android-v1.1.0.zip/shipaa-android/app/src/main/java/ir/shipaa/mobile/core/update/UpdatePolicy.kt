package ir.shipaa.mobile.core.update

/** Contents of the remote update manifest (see docs/MAINTENANCE-FA.md). */
data class UpdateManifest(
    val latestVersionCode: Int,
    val minSupportedVersionCode: Int,
    val versionName: String,
    val downloadUrl: String,
    val notes: String,
)

sealed interface UpdateDecision {
    data object UpToDate : UpdateDecision
    data class Optional(val manifest: UpdateManifest) : UpdateDecision
    data class Required(val manifest: UpdateManifest) : UpdateDecision
}

object UpdatePolicy {
    fun decide(currentVersionCode: Int, manifest: UpdateManifest?, dismissedVersionCode: Int = 0): UpdateDecision {
        if (manifest == null) return UpdateDecision.UpToDate
        if (!manifest.downloadUrl.startsWith("https://")) return UpdateDecision.UpToDate
        if (currentVersionCode < manifest.minSupportedVersionCode) return UpdateDecision.Required(manifest)
        if (manifest.latestVersionCode > currentVersionCode && manifest.latestVersionCode > dismissedVersionCode) {
            return UpdateDecision.Optional(manifest)
        }
        return UpdateDecision.UpToDate
    }

    /** versionCode = major*10000 + minor*100 + patch, matching app/build.gradle.kts. */
    fun versionCodeOf(semver: String): Int {
        val parts = semver.substringBefore('-').split('.').map { it.toIntOrNull() ?: 0 }
        val (major, minor, patch) = (parts + listOf(0, 0, 0)).take(3)
        require(minor in 0..99 && patch in 0..99) { "minor/patch must be 0..99" }
        return major * 10000 + minor * 100 + patch
    }
}
