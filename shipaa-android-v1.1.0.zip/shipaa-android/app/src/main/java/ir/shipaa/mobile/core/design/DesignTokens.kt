package ir.shipaa.mobile.core.design

/**
 * The single Shipaa design system shared by native screens (Compose theme) and
 * the UI that bridge.js injects into shipaa.ir pages (CSS custom properties).
 *
 * Values come from the Shipaa site styles (shipaa-offline-pwa v0.4.0 stylesheet and
 * the brand palette: white, grass green, lilac, sky blue). Change them here only.
 * Colors are ARGB longs so this file stays free of Android dependencies.
 */
object DesignTokens {

    object Color {
        const val primary = 0xFF136B4BL        // Shipaa green (buttons, links)
        const val primaryPressed = 0xFF0E5239L
        const val onPrimary = 0xFFFFFFFFL
        const val grass = 0xFF4AA148L          // brand grass green (accents, progress)
        const val background = 0xFFF5FAF6L     // page background
        const val surface = 0xFFFFFFFFL        // cards / panels
        const val surfaceMuted = 0xFFF0F4F1L   // chips, inactive
        const val ink = 0xFF203B34L            // primary text
        const val muted = 0xFF60766DL          // secondary text
        const val line = 0xFFDFEBE3L           // borders, dividers
        const val lineStrong = 0xFFC9E1D2L
        const val lilac = 0xFF7B5EA7L          // brand lilac
        const val lilacSoft = 0xFFF1ECFAL
        const val sky = 0xFF1F6FA8L            // brand sky blue
        const val skySoft = 0xFFE7F2FBL
        const val success = 0xFF167548L
        const val successSoft = 0xFFE9F7EDL
        const val warning = 0xFF915B24L
        const val warningSoft = 0xFFFFF4E5L
        const val danger = 0xFFA03735L
        const val dangerSoft = 0xFFFCEDEDL
        const val playerBackground = 0xFF151A17L
    }

    object Radius {
        const val panel = 18
        const val card = 12
        const val button = 10
        const val chip = 18
        const val field = 8
    }

    object Space {
        const val xxs = 4
        const val xs = 8
        const val sm = 12
        const val md = 16
        const val lg = 20
        const val xl = 24
        const val xxl = 32
        /** Minimum touch target in dp (Material / WCAG). */
        const val touch = 48
    }

    object Type {
        const val caption = 12
        const val small = 13
        const val body = 15
        const val title = 17
        const val heading = 21
        const val display = 26
        /** Persian text needs generous line height. */
        const val lineHeightRatio = 1.9f
    }

    object Motion {
        const val fastMs = 150
        const val baseMs = 220
        const val slowMs = 320
    }

    /** "#RRGGBB" for an ARGB long, alpha ignored. */
    fun hex(argb: Long): String = "#" + (argb and 0xFFFFFF).toString(16).padStart(6, '0').uppercase()

    /**
     * CSS custom properties injected into shipaa.ir pages so injected native controls
     * look exactly like native screens. Fonts are inherited from the site.
     */
    fun toCss(): String = buildString {
        append(":root{")
        val c = Color
        listOf(
            "primary" to c.primary, "primary-pressed" to c.primaryPressed, "on-primary" to c.onPrimary,
            "grass" to c.grass, "bg" to c.background, "surface" to c.surface, "surface-muted" to c.surfaceMuted,
            "ink" to c.ink, "muted" to c.muted, "line" to c.line, "line-strong" to c.lineStrong,
            "lilac" to c.lilac, "lilac-soft" to c.lilacSoft, "sky" to c.sky, "sky-soft" to c.skySoft,
            "success" to c.success, "success-soft" to c.successSoft, "warning" to c.warning,
            "warning-soft" to c.warningSoft, "danger" to c.danger, "danger-soft" to c.dangerSoft,
        ).forEach { (name, v) -> append("--shp-").append(name).append(':').append(hex(v)).append(';') }
        append("--shp-r-panel:${Radius.panel}px;--shp-r-card:${Radius.card}px;")
        append("--shp-r-button:${Radius.button}px;--shp-r-chip:${Radius.chip}px;")
        append("--shp-touch:${Space.touch}px;--shp-motion:${Motion.baseMs}ms;")
        append("}")
    }
}
