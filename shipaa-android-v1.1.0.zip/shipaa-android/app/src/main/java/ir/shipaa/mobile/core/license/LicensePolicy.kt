package ir.shipaa.mobile.core.license

import java.util.concurrent.TimeUnit

/**
 * Offline playback licence. A stored video stays playable for [validityMs] after the last
 * successful online check that the user still has access to the lesson on shipaa.ir.
 */
class LicensePolicy(
    val validityMs: Long = TimeUnit.DAYS.toMillis(30),
    /** A clock moved back further than this is treated as tampering. */
    val clockRollbackToleranceMs: Long = TimeUnit.HOURS.toMillis(24),
    /** Re-check in the background once this much of the window has passed. */
    val refreshAfterMs: Long = TimeUnit.DAYS.toMillis(3),
) {
    enum class Verdict { VALID, VALID_REFRESH_SOON, EXPIRED, CLOCK_TAMPERED }

    /**
     * @param verifiedAt wall-clock time of the last successful online verification
     * @param lastSeenAt the latest wall-clock time the app has ever observed (monotonic high-water mark)
     */
    fun evaluate(now: Long, verifiedAt: Long, lastSeenAt: Long): Verdict {
        if (lastSeenAt - now > clockRollbackToleranceMs) return Verdict.CLOCK_TAMPERED
        if (verifiedAt - now > clockRollbackToleranceMs) return Verdict.CLOCK_TAMPERED
        val age = now - verifiedAt
        return when {
            age > validityMs -> Verdict.EXPIRED
            age > refreshAfterMs -> Verdict.VALID_REFRESH_SOON
            else -> Verdict.VALID
        }
    }

    fun expiresAt(verifiedAt: Long): Long = verifiedAt + validityMs

    /** New high-water mark: never moves backwards. */
    fun advanceLastSeen(previous: Long, now: Long): Long = maxOf(previous, now)
}

/** Result of checking a lesson page for the stored video. */
enum class AccessCheck { GRANTED, REVOKED, LOGGED_OUT, UNKNOWN }

object LessonAccessVerifier {
    private val loginMarkers = listOf("woocommerce-form-login", "name=\"password\"", "id=\"loginform\"", "wp-login.php")

    /**
     * Decides from the HTML that the server returned for a lesson page (fetched with the user's
     * cookies) whether the user can still watch [videoUrlWithoutQuery].
     */
    fun decide(httpStatus: Int, finalUrl: String, html: String, videoUrlWithoutQuery: String): AccessCheck {
        if (httpStatus >= 500 || httpStatus == 0) return AccessCheck.UNKNOWN
        val path = videoUrlWithoutQuery.substringAfter("://").substringAfter('/')
        val fileName = path.substringAfterLast('/')
        val mentionsVideo = html.contains(path) || (fileName.length > 6 && html.contains(fileName)) ||
            html.contains(path.replace("/", "\\/"))
        if (mentionsVideo) return AccessCheck.GRANTED
        val looksLikeLogin = loginMarkers.any { html.contains(it) } ||
            (finalUrl.contains("/my-account") && html.contains("login"))
        if (looksLikeLogin) return AccessCheck.LOGGED_OUT
        if (httpStatus == 403 || httpStatus == 404 || httpStatus == 410) return AccessCheck.REVOKED
        // A normal page without the video link is NOT treated as revocation: the player may load
        // its source with JavaScript. The licence then simply waits for a visit to the lesson page.
        return AccessCheck.UNKNOWN
    }
}
