package ir.shipaa.mobile.download

import android.content.Context
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.download.DownloadAction
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Runs one download. Persisted by WorkManager across app restarts and reboots. */
class DownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val notifications = DownloadNotifications(context)

    override suspend fun doWork(): Result {
        AppGraph.ensure(applicationContext)
        val repo = AppGraph.repo
        val id = inputData.getString(KEY_ID) ?: return Result.failure()
        val initial = repo.get(id) ?: return Result.success()
        if (!initial.stateEnum.isActive) return Result.success()

        val connectivity = AppGraph.connectivity
        val wifiOnly = AppGraph.prefs.wifiOnly.value
        if (!connectivity.currentlyOnline() || (wifiOnly && connectivity.isMetered())) {
            repo.transition(id, DownloadAction.NETWORK_LOST)
            return Result.retry()
        }

        repo.transition(id, DownloadAction.START)
        tryForeground(notifications.foregroundInfo(initial, initial.percent, initial.totalBytes <= 0))

        var lastNotified = 0L
        val outcome = withContext(Dispatchers.IO) {
            DownloadEngine(repo, Http.client()).run(id, isStopped = { isStopped }) { entity, done, total ->
                val now = SystemClock.elapsedRealtime()
                if (now - lastNotified >= 1500) {
                    lastNotified = now
                    val pct = DownloadPresentation.percent(done, total, false)
                    tryForeground(notifications.foregroundInfo(entity, pct, total <= 0))
                }
            }
        }

        return when (outcome) {
            DownloadOutcome.Completed -> {
                val done = repo.transition(id, DownloadAction.COMPLETE)
                if (done?.stateEnum == DownloadState.COMPLETED) notifications.completed(done)
                Result.success()
            }
            // When the system stops a worker it reschedules it regardless of the result.
            DownloadOutcome.Stopped -> Result.retry()
            is DownloadOutcome.Failed -> handleFailure(id, outcome.error)
        }
    }

    private suspend fun handleFailure(id: String, error: DownloadError): Result {
        val repo = AppGraph.repo
        return if (error.retryable && runAttemptCount < MAX_ATTEMPTS) {
            repo.transition(id, DownloadAction.NETWORK_LOST, error)
            Result.retry()
        } else {
            val failed = repo.transition(id, DownloadAction.FAIL, error)
            if (failed != null && failed.stateEnum == DownloadState.FAILED) notifications.failed(failed, error)
            Result.failure()
        }
    }

    /** Android 12+ forbids starting a foreground service from the background (e.g. after reboot). */
    private suspend fun tryForeground(info: ForegroundInfo) {
        try { setForeground(info) } catch (_: IllegalStateException) { /* continue as normal work */ }
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        val id = inputData.getString(KEY_ID)
        val e = id?.let { AppGraph.repo.get(it) }
        return if (e != null) notifications.foregroundInfo(e, e.percent, e.totalBytes <= 0)
        else notifications.genericForegroundInfo()
    }

    companion object {
        const val KEY_ID = "id"
        /** About 4 hours of linear back-off (30s, 60s, 90s …) before a download is marked failed. */
        const val MAX_ATTEMPTS = 40
    }
}
