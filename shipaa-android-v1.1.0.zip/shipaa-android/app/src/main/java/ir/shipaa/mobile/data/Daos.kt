package ir.shipaa.mobile.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY course COLLATE NOCASE, createdAt")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    fun observe(id: String): Flow<DownloadEntity?>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE id IN (:ids)")
    suspend fun getAll(ids: List<String>): List<DownloadEntity>

    @Query("SELECT * FROM downloads")
    suspend fun all(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE state IN (:states)")
    suspend fun withStates(states: List<String>): List<DownloadEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(e: DownloadEntity)

    @Upsert
    suspend fun upsert(e: DownloadEntity)

    @Query("UPDATE downloads SET downloadedBytes = :bytes, totalBytes = :total, updatedAt = :now WHERE id = :id")
    suspend fun updateProgress(id: String, bytes: Long, total: Long, now: Long)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT COALESCE(SUM(downloadedBytes), 0) FROM downloads")
    fun observeUsedBytes(): Flow<Long>
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM progress WHERE ownerKey = :owner AND videoKey = :key")
    suspend fun get(owner: String, key: String): ProgressEntity?

    @Query("SELECT * FROM progress WHERE ownerKey = :owner")
    fun observeForOwner(owner: String): Flow<List<ProgressEntity>>

    @Query("SELECT * FROM progress WHERE ownerKey = :owner AND dirty = 1 LIMIT 200")
    suspend fun dirty(owner: String): List<ProgressEntity>

    @Upsert
    suspend fun upsert(p: ProgressEntity)

    @Upsert
    suspend fun upsertAll(p: List<ProgressEntity>)

    @Query("UPDATE progress SET dirty = 0 WHERE ownerKey = :owner AND videoKey IN (:keys) AND updatedAt <= :upTo")
    suspend fun markClean(owner: String, keys: List<String>, upTo: Long)
}
