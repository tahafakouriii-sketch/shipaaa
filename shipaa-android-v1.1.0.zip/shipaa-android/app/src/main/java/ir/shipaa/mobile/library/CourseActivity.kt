package ir.shipaa.mobile.library

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.course.CourseInfo
import ir.shipaa.mobile.core.course.CourseLesson
import ir.shipaa.mobile.core.course.CourseOffline
import ir.shipaa.mobile.core.course.CourseSection
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.player.PlayerActivity
import ir.shipaa.mobile.ui.components.ButtonKind
import ir.shipaa.mobile.ui.components.MessageState
import ir.shipaa.mobile.ui.components.Panel
import ir.shipaa.mobile.ui.components.ProgressLine
import ir.shipaa.mobile.ui.components.ShipaaButton
import ir.shipaa.mobile.ui.components.StatusChip
import ir.shipaa.mobile.ui.theme.ShipaaColors
import ir.shipaa.mobile.ui.theme.ShipaaTheme
import ir.shipaa.mobile.web.MainActivity
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * A saved course shown with the same structure as its Studiare page (sections → numbered lessons),
 * usable without internet: saved lessons play from the encrypted copy.
 */
class CourseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        AppGraph.ensure(this)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val key = intent.getStringExtra(EXTRA_KEY)?.takeIf { it.matches(Regex("^[0-9a-f]{24}$")) } ?: run { finish(); return }
        AppGraph.session.refresh()
        setContent { ShipaaTheme { CourseScreen(this, key) } }
    }

    internal fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    internal fun play(course: CourseInfo, lesson: CourseLesson) {
        val src = lesson.src ?: return
        startActivity(PlayerActivity.createIntent(this, VideoInfo(src, lesson.title, course.title, null, course.pageUrl, null)))
    }

    internal fun openOnSite(course: CourseInfo) = MainActivity.open(this, course.pageUrl)

    companion object {
        private const val EXTRA_KEY = "course"
        fun start(context: Context, key: String) =
            context.startActivity(Intent(context, CourseActivity::class.java).putExtra(EXTRA_KEY, key))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CourseScreen(activity: CourseActivity, key: String) {
    val scope = rememberCoroutineScope()
    val account by AppGraph.session.account.collectAsState()
    val owner = account?.ownerKey ?: ""
    val online by AppGraph.connectivity.online.collectAsState()
    val course by remember(owner) { AppGraph.courses.observe(owner).map { list -> list.firstOrNull { it.key == key } } }
        .collectAsState(initial = null)
    val downloads by remember { AppGraph.repo.observeAll().map { all -> all.associateBy { it.id } } }
        .collectAsState(initial = emptyMap())
    val progress by remember(owner) { AppGraph.repo.observeProgress(owner) }.collectAsState(initial = emptyList())
    val watched = remember(progress) {
        progress.associate { it.videoKey to (if (it.durationMs > 0) it.positionMs.toFloat() / it.durationMs else 0f) }
    }
    val expanded = remember { mutableStateMapOf<Int, Boolean>() }

    fun entityOf(lesson: CourseLesson): DownloadEntity? =
        lesson.src?.let { downloads[VideoUrlPolicy.keyOf(it)] }?.takeIf { it.ownerKey == owner }

    Column(Modifier.fillMaxSize().background(ShipaaColors.background).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(ShipaaColors.surface).padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { activity.finish() }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = ShipaaColors.ink)
            }
            Text(
                course?.title ?: "دوره",
                style = MaterialTheme.typography.titleMedium, color = ShipaaColors.ink,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            if (!online) {
                Icon(Icons.Rounded.WifiOff, contentDescription = "آفلاین", tint = ShipaaColors.warning, modifier = Modifier.padding(end = 14.dp).size(20.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(ShipaaColors.line))

        val c = course
        if (c == null) {
            MessageState(
                icon = Icons.Rounded.School,
                title = "این دوره روی گوشی ذخیره نشده",
                body = "صفحه دوره را یک بار با اینترنت در اپ باز کنید تا فهرست جلسات آن برای حالت آفلاین ذخیره شود.",
                modifier = Modifier.fillMaxWidth(),
            )
            return@Column
        }
        val summary = CourseOffline.summary(c) { src -> downloads[VideoUrlPolicy.keyOf(src)]?.takeIf { it.ownerKey == owner }?.stateEnum }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(DesignTokens.Space.md.dp),
            verticalArrangement = Arrangement.spacedBy(DesignTokens.Space.sm.dp),
        ) {
            item {
                Panel {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.School, contentDescription = null, tint = ShipaaColors.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("محتوای دوره", style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink, modifier = Modifier.weight(1f))
                            Text(
                                "${PersianFormat.number(c.sections.size)} فصل · ${PersianFormat.number(c.lessons.size)} جلسه",
                                style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
                            )
                        }
                        ProgressLine(summary.fraction, color = ShipaaColors.grass)
                        Text(
                            "${PersianFormat.number(summary.saved)} از ${PersianFormat.number(summary.videoLessons)} جلسه آماده تماشای آفلاین" +
                                if (summary.downloading > 0) " · ${PersianFormat.number(summary.downloading)} جلسه در حال ذخیره" else "",
                            style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
                        )
                        if (online) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                val remaining = c.lessons.filter { it.src != null && entityOf(it)?.stateEnum != DownloadState.COMPLETED }
                                if (remaining.isNotEmpty() && summary.downloading == 0) {
                                    ShipaaButton(
                                        if (summary.saved == 0) "ذخیره همه جلسات (${PersianFormat.number(remaining.size)})"
                                        else "ذخیره بقیه جلسات (${PersianFormat.number(remaining.size)})",
                                        {
                                            val ownerNow = AppGraph.session.refresh()?.takeIf { it.fromLiveCookie }?.ownerKey
                                            if (ownerNow == null) activity.toast("برای ذخیره، ابتدا وارد حساب کاربری شوید")
                                            else scope.launch {
                                                remaining.forEach { l ->
                                                    AppGraph.scheduler.enqueue(VideoInfo(l.src!!, l.title, c.title, null, c.pageUrl, null), ownerNow)
                                                }
                                                activity.toast("${PersianFormat.number(remaining.size)} جلسه به صف ذخیره اضافه شد")
                                            }
                                        },
                                        kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Download,
                                    )
                                }
                                ShipaaButton("صفحه دوره در سایت", { activity.openOnSite(c) }, icon = Icons.Rounded.Language)
                            }
                        } else {
                            Text(
                                "حالت آفلاین: جلسه‌هایی که ذخیره کرده‌اید قابل پخش‌اند.",
                                style = MaterialTheme.typography.labelMedium, color = ShipaaColors.warning,
                            )
                        }
                    }
                }
            }
            itemsIndexed(c.sections) { index, section ->
                val hasSaved = section.lessons.any { entityOf(it)?.stateEnum == DownloadState.COMPLETED }
                val isOpen = expanded[index] ?: (hasSaved || index == 0)
                SectionCard(
                    section = section,
                    open = isOpen,
                    onToggle = { expanded[index] = !isOpen },
                    savedCount = section.lessons.count { entityOf(it)?.stateEnum == DownloadState.COMPLETED },
                    videoCount = section.lessons.count { it.src != null },
                ) {
                    section.lessons.forEachIndexed { i, lesson ->
                        if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(ShipaaColors.line))
                        val e = entityOf(lesson)
                        LessonRow(
                            lesson = lesson,
                            entity = e,
                            watched = lesson.src?.let { watched[VideoUrlPolicy.keyOf(it)] } ?: 0f,
                            online = online,
                            onPlay = {
                                when {
                                    lesson.src == null -> activity.toast(if (lesson.quiz) "آزمون فقط در سایت و با اینترنت انجام می‌شود" else "این جلسه ویدئو ندارد")
                                    e?.stateEnum == DownloadState.COMPLETED || online -> activity.play(c, lesson)
                                    else -> activity.toast("این جلسه ذخیره نشده است؛ با اینترنت آن را ذخیره کنید")
                                }
                            },
                            onDownload = {
                                val ownerNow = AppGraph.session.refresh()?.takeIf { it.fromLiveCookie }?.ownerKey
                                val src = lesson.src
                                if (ownerNow == null) activity.toast("برای ذخیره، ابتدا وارد حساب کاربری شوید")
                                else if (src != null) scope.launch {
                                    AppGraph.scheduler.enqueue(VideoInfo(src, lesson.title, c.title, null, c.pageUrl, null), ownerNow)
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    section: CourseSection,
    open: Boolean,
    onToggle: () -> Unit,
    savedCount: Int,
    videoCount: Int,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(DesignTokens.Radius.panel.dp)
    val rotation by animateFloatAsState(if (open) 180f else 0f, label = "chevron")
    Column(Modifier.fillMaxWidth().clip(shape).background(ShipaaColors.surface).border(1.dp, ShipaaColors.line, shape)) {
        Row(
            Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onToggle).padding(DesignTokens.Space.md.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (section.label.isNotBlank() || section.number.isNotBlank()) {
                Box(
                    Modifier.clip(RoundedCornerShape(DesignTokens.Radius.chip.dp)).background(ShipaaColors.successSoft)
                        .padding(horizontal = 10.dp, vertical = 3.dp),
                ) {
                    Text(
                        PersianFormat.digits(listOf(section.label, section.number).filter { it.isNotBlank() }.joinToString(" ")),
                        style = MaterialTheme.typography.labelMedium, color = ShipaaColors.primary,
                    )
                }
                Spacer(Modifier.width(8.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(section.title.ifBlank { "جلسات" }, style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink)
                if (videoCount > 0) {
                    Text(
                        "${PersianFormat.number(savedCount)} از ${PersianFormat.number(videoCount)} ذخیره‌شده",
                        style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
                    )
                }
            }
            Icon(Icons.Rounded.ExpandMore, contentDescription = if (open) "بستن فصل" else "باز کردن فصل",
                tint = ShipaaColors.muted, modifier = Modifier.rotate(rotation))
        }
        AnimatedVisibility(visible = open) {
            Column(Modifier.fillMaxWidth().padding(horizontal = DesignTokens.Space.sm.dp).padding(bottom = DesignTokens.Space.xs.dp)) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(ShipaaColors.line))
                content()
            }
        }
    }
}

@Composable
private fun LessonRow(
    lesson: CourseLesson,
    entity: DownloadEntity?,
    watched: Float,
    online: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit,
) {
    val state = entity?.stateEnum
    val saved = state == DownloadState.COMPLETED
    val playable = lesson.src != null && (saved || online)
    Row(
        Modifier.fillMaxWidth()
            .clickable(role = Role.Button, onClick = onPlay)
            .padding(vertical = 10.dp, horizontal = 4.dp)
            .alpha(if (playable || lesson.quiz) 1f else 0.6f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(if (saved) ShipaaColors.successSoft else ShipaaColors.surfaceMuted),
            contentAlignment = Alignment.Center,
        ) {
            when {
                lesson.quiz -> Icon(Icons.Rounded.Quiz, null, tint = ShipaaColors.lilac, modifier = Modifier.size(18.dp))
                lesson.locked -> Icon(Icons.Rounded.Lock, null, tint = ShipaaColors.muted, modifier = Modifier.size(18.dp))
                else -> Text(PersianFormat.digits(lesson.number), style = MaterialTheme.typography.labelLarge,
                    color = if (saved) ShipaaColors.primary else ShipaaColors.muted)
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(lesson.title, style = MaterialTheme.typography.bodyMedium, color = ShipaaColors.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (lesson.subtitle.isNotBlank()) {
                Text(lesson.subtitle, style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            when {
                entity != null -> StatusChip(entity.stateEnum, entity.errorEnum, entity.percent)
                lesson.quiz -> Unit
                lesson.locked -> Text("قفل در سایت", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
                lesson.src != null -> Text(
                    if (online) "ذخیره نشده" else "ذخیره نشده — نیاز به اینترنت",
                    style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
                )
            }
            if (saved && watched > 0.01f) ProgressLine(watched, color = ShipaaColors.grass)
        }
        Spacer(Modifier.width(6.dp))
        when {
            lesson.src == null -> Unit
            saved -> RoundAction(Icons.Rounded.PlayArrow, "پخش", ShipaaColors.primary, ShipaaColors.successSoft, onPlay)
            state != null && state.isActive -> Unit
            online -> RoundAction(Icons.Rounded.Download, "ذخیره برای آفلاین", ShipaaColors.primary, ShipaaColors.surfaceMuted, onDownload)
            else -> Icon(Icons.Rounded.CloudOff, contentDescription = "نیاز به اینترنت", tint = ShipaaColors.muted, modifier = Modifier.padding(10.dp).size(20.dp))
        }
    }
}

@Composable
private fun RoundAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: androidx.compose.ui.graphics.Color,
    bg: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Box(
        Modifier.size(DesignTokens.Space.touch.dp).clip(CircleShape).clickable(role = Role.Button, onClickLabel = label, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
    }
}
