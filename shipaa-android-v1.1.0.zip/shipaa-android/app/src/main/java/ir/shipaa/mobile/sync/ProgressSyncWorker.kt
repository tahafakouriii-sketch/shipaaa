package ir.shipaa.mobile.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.BuildConfig
import ir.shipaa.mobile.core.progress.WatchProgress
import ir.shipaa.mobile.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Sends local watch positions to the optional WordPress plugin "shipaa-app-sync" and merges
 * the server copy back. Without the plugin this disables itself for a day and does nothing.
 */
class ProgressSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        AppGraph.ensure(applicationContext)
        val prefs = AppGraph.prefs
        val now = System.currentTimeMillis()
        if (now < prefs.syncDisabledUntil) return Result.success()
        val owner = AppGraph.session.refresh()?.takeIf { it.fromLiveCookie }?.ownerKey ?: return Result.success()
        val nonce = prefs.syncNonce?.takeIf { now - prefs.syncNonceAt < NONCE_MAX_AGE } ?: return Result.success()
        if (!AppGraph.connectivity.currentlyOnline()) return Result.retry()

        val repo = AppGraph.repo
        val dirty = repo.dirtyProgress(owner)
        val items = JSONArray()
        dirty.forEach {
            items.put(JSONObject().put("k", it.videoKey).put("p", it.positionMs).put("d", it.durationMs).put("t", it.updatedAt))
        }
        val body = FormBody.Builder()
            .add("action", ACTION)
            .add("_ajax_nonce", nonce)
            .add("items", items.toString())
            .build()
        val request = Request.Builder().url(BuildConfig.SYNC_AJAX_URL).post(body).build()

        val text = try {
            withContext(Dispatchers.IO) {
                Http.client().newCall(request).execute().use { r ->
                    if (r.code == 400 || r.code == 404) null else r.body?.string()?.take(2_000_000)
                }
            }
        } catch (_: Exception) {
            return Result.retry()
        }
        // admin-ajax answers "0" / 400 when no plugin handles the action.
        if (text == null || text.trim() == "0" || text.trim() == "-1") {
            if (text?.trim() == "-1") prefs.syncNonce = null // expired nonce: wait for a fresh page
            else prefs.syncDisabledUntil = now + TimeUnit.DAYS.toMillis(1)
            return Result.success()
        }
        val remote = try {
            val o = JSONObject(text)
            if (!o.optBoolean("success")) {
                // Expired nonce: wait for the next page load to provide a fresh one.
                if (o.optJSONObject("data")?.optString("code") == "bad_nonce") prefs.syncNonce = null
                return Result.success()
            }
            val arr = o.getJSONObject("data").getJSONArray("items")
            (0 until arr.length()).mapNotNull { i ->
                val x = arr.getJSONObject(i)
                val k = x.optString("k")
                if (!k.matches(Regex("^[0-9a-f]{32}$"))) null
                else WatchProgress(k, x.optLong("p"), x.optLong("d"), x.optLong("t"))
            }
        } catch (_: Exception) {
            return Result.success()
        }
        repo.applyRemoteProgress(owner, remote, dirty.map { it.videoKey }, dirty.maxOfOrNull { it.updatedAt } ?: 0L)
        return Result.success()
    }

    companion object {
        const val ACTION = "shipaa_app_progress_sync"
        private val NONCE_MAX_AGE = TimeUnit.HOURS.toMillis(11)

        fun request(context: Context) {
            val r = OneTimeWorkRequestBuilder<ProgressSyncWorker>()
                .setInitialDelay(10, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork("progress-sync", ExistingWorkPolicy.REPLACE, r)
        }
    }
}
