/*
 * Shipaa app bridge — injected by the Android app into shipaa.ir pages only.
 *
 * Built for the Studiare theme (v13.x) used by shipaa.ir:
 *   course page (WooCommerce product) → .course-section → .panel-group → .course-lesson
 *   lesson media → .sc_le_vi_au > video.studi_lesson_video > source[src]   (Suncode Player wraps the video)
 *   lesson title → .course-lesson .course-panel-heading .title h4 (minus .badge-item)
 * Lessons the user cannot access are rendered WITHOUT a video, so a video in the page means access.
 *
 * What it adds (never modifies or removes the site's own elements):
 *   - under each lesson player: "پخش در پلیر شیپا" / "ذخیره برای آفلاین" / "کتابخانه من"
 *   - above the curriculum: "ذخیره همه جلسات" with the course's offline status
 * It reports the course curriculum so the app can show it offline.
 * Every element it creates is prefixed "shp-app-". Errors are swallowed so the site keeps working.
 */
(function () {
  'use strict';
  if (window.ShipaaApp && window.ShipaaApp.__ready) return;

  var BRIDGE_VERSION = 2;
  var VIDEO_RE = /^https:\/\/dl\.shipaa\.ir\/[^?#]+\.(mp4|m4v)(\?[^#]*)?$/i;
  var MAX_ITEMS = 300;
  // Containers to place the bar AFTER (outside of any player chrome). First match wins.
  var MEDIA_BOXES = ['.sc_le_vi_au'];
  var PLAYER_WRAPPERS = '.scplayer, .plyr, .video-js, .mejs-container, .wp-video, .jw-wrapper, .video-container';
  var S = {
    lesson: '.course-lesson',
    lessonTitle: ['.course-panel-heading .title h4', '.course-panel-heading .title-inner', '.course-panel-heading .title'],
    lessonSubtitle: '.course-panel-heading .subtitle',
    lessonNumber: '.course-panel-heading .lesson-number',
    badge: '.badge-item',
    section: '.course-section',
    sectionTitle: '.course-section-title',
    sectionLabel: '.scchapturetitle',
    sectionNumber: '.scchapturenumber',
    locked: '.lessonaccessdenied, .lesson-locked-message',
    quiz: '.scquiz',
    courseTitle: 'h1.product_title, .product_title, h1.entry-title, h1',
    courseAnchor: ['.course-summary', '.course-content-header']
  };
  // Site-specific selectors that close an open mobile/side menu or popup on Android "back".
  var BACK_CLOSERS = [
    '.mfp-close', '.mobile-menu.active .close', '.mobile-menu.open .close', '.offcanvas.show .btn-close',
    '.offcanvas-close', '.side-menu.active .close', '.menu-close', '.modal.show [data-bs-dismiss="modal"]',
    '.modal.show [data-dismiss="modal"]', '.popup.active .close', '.studi-modal.active .close'
  ];

  var tokensCss = (typeof window.__SHP_TOKENS__ === 'string') ? window.__SHP_TOKENS__ : '';
  var states = {};      // src -> {state, percent, label, tone}
  var bars = [];        // {video, src, bar, play, dl, lib, status}
  var courseBar = null; // {bar, dl, lib, status}
  var reported = '';
  var reportedCourse = '';
  var reportedDiag = '';

  function post(msg) {
    try {
      var n = window.ShipaaNative;
      if (n && typeof n.postMessage === 'function') n.postMessage(JSON.stringify(msg));
    } catch (e) { /* never break the page */ }
  }

  function faDigits(s) {
    return String(s).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+d); });
  }

  function cleanText(s) { return (s || '').replace(/\s+/g, ' ').trim().slice(0, 300); }

  /** Text of an element without its badge / chapter-number children. */
  function ownText(el, drop) {
    if (!el) return '';
    var c = el.cloneNode(true);
    var junk = c.querySelectorAll(drop || (S.badge + ', a, .chapterholder, svg, i'));
    for (var i = 0; i < junk.length; i++) junk[i].parentNode.removeChild(junk[i]);
    return cleanText(c.textContent);
  }

  function absolute(u) {
    try { return new URL(u, location.href).href; } catch (e) { return null; }
  }

  function rawSources(v) {
    var cands = [v.currentSrc, v.getAttribute('src')];
    var sources = v.querySelectorAll('source');
    for (var i = 0; i < sources.length; i++) cands.push(sources[i].getAttribute('src'));
    return cands.filter(Boolean);
  }

  function videoSrc(v) {
    var cands = rawSources(v);
    for (var j = 0; j < cands.length; j++) {
      var a = absolute(cands[j]);
      if (a && VIDEO_RE.test(a)) return a.split('#')[0];
    }
    return null;
  }

  function postId() {
    var m = (document.body && document.body.className || '').match(/(?:^|\s)postid-(\d+)(?:\s|$)/);
    return m ? parseInt(m[1], 10) : null;
  }

  function courseName() {
    var h = document.querySelector(S.courseTitle);
    if (h && cleanText(h.textContent)) return cleanText(h.textContent);
    var crumbs = document.querySelectorAll('.woocommerce-breadcrumb a, .breadcrumb a, .breadcrumbs a');
    if (crumbs.length > 1) return cleanText(crumbs[crumbs.length - 1].textContent);
    return cleanText(document.title.replace(/\s*[-–|]\s*شیپا.*$/, ''));
  }

  function lessonOf(el) { return el && el.closest ? el.closest(S.lesson) : null; }

  function lessonTitle(lesson) {
    if (!lesson) return '';
    for (var i = 0; i < S.lessonTitle.length; i++) {
      var t = ownText(lesson.querySelector(S.lessonTitle[i]), S.badge + ', a, .subtitle, svg, i');
      if (t) return t;
    }
    return '';
  }

  function titleFor(v) {
    var t = lessonTitle(lessonOf(v));
    if (t) return t;
    var node = v;
    for (var i = 0; node && i < 6; i++, node = node.parentElement) {
      var h = node.querySelector && node.querySelector('.lesson-title, h2, h3, h4');
      if (h && cleanText(h.textContent)) return cleanText(h.textContent);
    }
    return courseName();
  }

  function infoFor(v, src) {
    return {
      src: src,
      title: titleFor(v),
      course: courseName(),
      lessonId: null,
      pageUrl: location.href.split('#')[0],
      poster: v.poster ? absolute(v.poster) : null
    };
  }

  // ---------- styles ----------
  function ensureStyle() {
    if (document.getElementById('shp-app-style')) return;
    var css = tokensCss +
      '.shp-app-bar{direction:rtl;font:inherit;display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:10px 0 14px;' +
      'padding:10px 12px;background:var(--shp-surface,#fff);border:1px solid var(--shp-line,#dfebe3);border-radius:var(--shp-r-card,12px);' +
      'box-shadow:0 6px 26px rgba(12,61,35,.04);box-sizing:border-box;width:100%;clear:both;position:relative;z-index:2}' +
      '.shp-app-course{margin:12px 0 16px;border-color:var(--shp-line-strong,#c9e1d2);background:var(--shp-bg,#f5faf6)}' +
      '.shp-app-course .shp-app-head{flex:1 0 100%;display:flex;align-items:center;gap:8px;font-weight:700;color:var(--shp-ink,#203b34);font-size:14px}' +
      '.shp-app-btn{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:6px;' +
      'min-height:var(--shp-touch,48px);padding:0 14px;border-radius:var(--shp-r-button,10px);font:inherit;font-size:13px;font-weight:700;' +
      'cursor:pointer;border:1px solid #cddfd5;background:#fff;color:var(--shp-primary,#136b4b);flex:1 1 auto;' +
      'transition:background var(--shp-motion,220ms),transform var(--shp-motion,220ms);-webkit-tap-highlight-color:transparent}' +
      '.shp-app-btn:active{transform:scale(.98)}' +
      '.shp-app-btn.primary{background:var(--shp-primary,#136b4b);border-color:var(--shp-primary,#136b4b);color:#fff}' +
      '.shp-app-btn[disabled]{opacity:.55;pointer-events:none}' +
      '.shp-app-btn svg{width:18px;height:18px;flex:none;fill:currentColor}' +
      '.shp-app-lib{flex:0 0 auto;padding:0 12px}' +
      '.shp-app-status{flex:1 0 100%;display:flex;align-items:center;gap:8px;font-size:12px;line-height:1.8;color:var(--shp-muted,#60766d)}' +
      '.shp-app-status:empty{display:none}' +
      '.shp-app-chip{display:inline-flex;align-items:center;gap:4px;border-radius:var(--shp-r-chip,18px);padding:2px 10px;font-weight:600}' +
      '.shp-app-chip.SUCCESS{color:var(--shp-success);background:var(--shp-success-soft)}' +
      '.shp-app-chip.PROGRESS{color:var(--shp-sky);background:var(--shp-sky-soft)}' +
      '.shp-app-chip.NEUTRAL{color:var(--shp-muted);background:var(--shp-surface-muted)}' +
      '.shp-app-chip.WARNING{color:var(--shp-warning);background:var(--shp-warning-soft)}' +
      '.shp-app-chip.DANGER{color:var(--shp-danger);background:var(--shp-danger-soft)}' +
      '.shp-app-chip.LOCKED{color:var(--shp-lilac);background:var(--shp-lilac-soft)}' +
      '.shp-app-progress{flex:1 1 auto;height:6px;border-radius:6px;background:var(--shp-surface-muted,#f0f4f1);overflow:hidden;min-width:60px}' +
      '.shp-app-progress>i{display:block;height:100%;background:var(--shp-sky,#1f6fa8);border-radius:6px;transition:width .4s}' +
      '.shipaa-app-only{display:revert !important}';
    var style = document.createElement('style');
    style.id = 'shp-app-style';
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }

  var ICON = {
    play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86A1 1 0 0 0 8 5.14z"/></svg>',
    down: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a1 1 0 0 1 1 1v9.59l3.3-3.3a1 1 0 1 1 1.4 1.42l-5 5a1 1 0 0 1-1.4 0l-5-5a1 1 0 1 1 1.4-1.42l3.3 3.3V4a1 1 0 0 1 1-1zM5 19h14a1 1 0 1 1 0 2H5a1 1 0 1 1 0-2z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0V6a1 1 0 0 1 1-1zm8 0a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0V6a1 1 0 0 1 1-1z"/></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9.55 17.6 4.4 12.45l1.4-1.4 3.75 3.74 8.65-8.64 1.4 1.4z"/></svg>',
    lib: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6H2v14a2 2 0 0 0 2 2h14v-2H4V6zm16-4H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm-8 12.5v-9l6 4.5-6 4.5z"/></svg>'
  };

  function button(cls, icon, label, onClick) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'shp-app-btn ' + cls;
    setButton(b, icon, label, false);
    b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); onClick(); });
    return b;
  }

  function setButton(b, icon, label, disabled) {
    b.innerHTML = icon + '<span></span>';
    b.lastChild.textContent = label;
    if (disabled) b.setAttribute('disabled', ''); else b.removeAttribute('disabled');
  }

  // ---------- placement ----------
  /** The element the bar goes after: Studiare's media box, else the outermost player wrapper, else the video. */
  function anchorFor(v) {
    for (var i = 0; i < MEDIA_BOXES.length; i++) {
      var box = v.closest && v.closest(MEDIA_BOXES[i]);
      if (box) return box;
    }
    var w = v.parentElement && v.parentElement.closest ? v.parentElement.closest(PLAYER_WRAPPERS) : null;
    var outer = w;
    while (outer && outer.parentElement && outer.parentElement.closest && outer.parentElement.closest(PLAYER_WRAPPERS)) {
      outer = outer.parentElement.closest(PLAYER_WRAPPERS);
    }
    return outer || v;
  }

  function place(entry) {
    var anchor = anchorFor(entry.video);
    if (!anchor.parentNode) return;
    // Players may re-wrap the video after we attached: keep the bar right after the anchor, outside the player.
    if (anchor.nextSibling !== entry.bar) anchor.parentNode.insertBefore(entry.bar, anchor.nextSibling);
  }

  // ---------- lesson bars ----------
  function attach(v) {
    if (v.getAttribute('data-shp-app') === '1') return;
    var src = videoSrc(v);
    if (!src) return;
    v.setAttribute('data-shp-app', '1');
    ensureStyle();
    var bar = document.createElement('div');
    bar.className = 'shp-app-bar';
    bar.setAttribute('data-shp-src', src);
    var entry = { video: v, src: src, bar: bar };
    entry.play = button('primary', ICON.play, 'پخش در پلیر شیپا', function () {
      try { v.pause(); } catch (e) {}
      post(Object.assign({ type: 'play' }, infoFor(v, src)));
    });
    entry.dl = button('', ICON.down, 'ذخیره برای آفلاین', function () { onDownloadTap(entry); });
    entry.lib = button('shp-app-lib', ICON.lib, 'کتابخانه من', function () { post({ type: 'openLibrary' }); });
    entry.status = document.createElement('div');
    entry.status.className = 'shp-app-status';
    bar.appendChild(entry.play); bar.appendChild(entry.dl); bar.appendChild(entry.lib); bar.appendChild(entry.status);
    bars.push(entry);
    place(entry);
    render(entry);
  }

  function onDownloadTap(entry) {
    var s = states[entry.src];
    var st = s && s.state;
    if (st === 'DOWNLOADING' || st === 'QUEUED' || st === 'WAITING_NETWORK') post({ type: 'pause', src: entry.src });
    else if (st === 'PAUSED' || st === 'FAILED') post({ type: 'resume', src: entry.src });
    else if (st === 'COMPLETED') post({ type: 'openLibrary' });
    else post(Object.assign({ type: 'download' }, infoFor(entry.video, entry.src)));
  }

  function render(entry) {
    var s = states[entry.src];
    var st = s ? s.state : null;
    var pct = s && typeof s.percent === 'number' ? s.percent : 0;
    if (st === 'COMPLETED') setButton(entry.dl, ICON.check, 'ذخیره‌شده — کتابخانه', false);
    else if (st === 'DOWNLOADING') setButton(entry.dl, ICON.pause, 'توقف دانلود ' + faDigits(pct) + '٪', false);
    else if (st === 'QUEUED' || st === 'WAITING_NETWORK') setButton(entry.dl, ICON.pause, 'توقف (در صف)', false);
    else if (st === 'PAUSED') setButton(entry.dl, ICON.down, 'ادامه دانلود ' + faDigits(pct) + '٪', false);
    else if (st === 'FAILED') setButton(entry.dl, ICON.down, 'تلاش دوباره', false);
    else if (st === 'NEEDS_VERIFICATION' || st === 'LOCKED') setButton(entry.dl, ICON.down, 'ذخیره دوباره برای این حساب', false);
    else setButton(entry.dl, ICON.down, 'ذخیره برای آفلاین', false);

    entry.status.innerHTML = '';
    if (s && s.label) {
      var chip = document.createElement('span');
      chip.className = 'shp-app-chip ' + (s.tone || 'NEUTRAL');
      chip.textContent = s.label;
      entry.status.appendChild(chip);
      if (st === 'DOWNLOADING' || st === 'PAUSED' || st === 'WAITING_NETWORK' || st === 'QUEUED') {
        var p = document.createElement('span');
        p.className = 'shp-app-progress';
        var i = document.createElement('i');
        i.style.width = Math.max(0, Math.min(100, pct)) + '%';
        p.appendChild(i);
        entry.status.appendChild(p);
      }
    }
  }

  // ---------- course page ----------
  function courseStructure() {
    var lessonEls = document.querySelectorAll(S.lesson);
    if (!lessonEls.length) return null;
    var sectionEls = document.querySelectorAll(S.section);
    var groups = [];
    if (sectionEls.length) {
      for (var i = 0; i < sectionEls.length; i++) groups.push({ el: sectionEls[i], lessons: sectionEls[i].querySelectorAll(S.lesson) });
    } else {
      groups.push({ el: null, lessons: lessonEls });
    }
    var sections = [];
    groups.forEach(function (g) {
      var lessons = [];
      for (var j = 0; j < g.lessons.length; j++) {
        var l = g.lessons[j];
        var v = l.querySelector('video');
        var num = l.querySelector(S.lessonNumber);
        var badge = l.querySelector('.course-panel-heading ' + S.badge);
        var sub = l.querySelector(S.lessonSubtitle);
        var title = lessonTitle(l);
        if (!title) continue;
        lessons.push({
          title: title,
          subtitle: sub ? cleanText(sub.textContent) : '',
          badge: badge ? cleanText(badge.textContent) : '',
          number: num ? cleanText(num.textContent) : String(j + 1),
          src: v ? videoSrc(v) : null,
          locked: !!l.querySelector(S.locked),
          quiz: !!l.querySelector(S.quiz)
        });
      }
      if (!lessons.length) return;
      var t = g.el && g.el.querySelector(S.sectionTitle);
      var label = g.el && g.el.querySelector(S.sectionLabel);
      var number = g.el && g.el.querySelector(S.sectionNumber);
      sections.push({
        title: t ? ownText(t, '.chapterholder, ' + S.badge + ', svg, i') : '',
        label: label ? cleanText(label.textContent) : '',
        number: number ? cleanText(number.textContent) : '',
        lessons: lessons
      });
    });
    if (!sections.length) return null;
    var img = document.querySelector('meta[property="og:image"]');
    return {
      type: 'course',
      postId: postId(),
      title: courseName(),
      pageUrl: location.href.split('#')[0],
      image: img ? img.getAttribute('content') : null,
      sections: sections
    };
  }

  function courseVideos() {
    return bars.filter(function (e) { return !!lessonOf(e.video); });
  }

  function ensureCourseBar() {
    var vids = courseVideos();
    if (!vids.length) { if (courseBar && courseBar.bar.parentNode) courseBar.bar.parentNode.removeChild(courseBar.bar); courseBar = null; return; }
    if (!courseBar) {
      var bar = document.createElement('div');
      bar.className = 'shp-app-bar shp-app-course';
      var head = document.createElement('div');
      head.className = 'shp-app-head';
      head.textContent = 'تماشای این دوره بدون اینترنت';
      courseBar = { bar: bar };
      courseRenderKey = '';
      courseBar.dl = button('primary', ICON.down, 'ذخیره همه جلسات', function () {
        post({ type: 'downloadAll', items: courseVideos().map(function (e) { return infoFor(e.video, e.src); }) });
      });
      courseBar.lib = button('shp-app-lib', ICON.lib, 'کتابخانه من', function () { post({ type: 'openLibrary' }); });
      courseBar.status = document.createElement('div');
      courseBar.status.className = 'shp-app-status';
      bar.appendChild(head); bar.appendChild(courseBar.dl); bar.appendChild(courseBar.lib); bar.appendChild(courseBar.status);
    }
    var anchor = null;
    for (var a = 0; a < S.courseAnchor.length && !anchor; a++) anchor = document.querySelector(S.courseAnchor[a]);
    var firstSection = document.querySelector(S.section) || lessonOf(vids[0].video);
    if (anchor && anchor.parentNode) {
      if (anchor.nextSibling !== courseBar.bar) anchor.parentNode.insertBefore(courseBar.bar, anchor.nextSibling);
    } else if (firstSection && firstSection.parentNode && firstSection.previousSibling !== courseBar.bar) {
      firstSection.parentNode.insertBefore(courseBar.bar, firstSection);
    }
    renderCourse();
  }

  var courseRenderKey = '';
  function renderCourse() {
    if (!courseBar) return;
    var vids = courseVideos();
    var total = vids.length, saved = 0, active = 0;
    vids.forEach(function (e) {
      var st = states[e.src] && states[e.src].state;
      if (st === 'COMPLETED') saved++;
      else if (st === 'DOWNLOADING' || st === 'QUEUED' || st === 'WAITING_NETWORK') active++;
    });
    // Only touch the DOM when something changed (our own mutations would trigger another scan).
    var rk = total + '/' + saved + '/' + active;
    if (rk === courseRenderKey) return;
    courseRenderKey = rk;
    if (total > 0 && saved === total) setButton(courseBar.dl, ICON.check, 'همه جلسات ذخیره شده‌اند', true);
    else if (active > 0) setButton(courseBar.dl, ICON.down, 'در حال ذخیره ' + faDigits(active) + ' جلسه…', true);
    else setButton(courseBar.dl, ICON.down, saved > 0 ? 'ذخیره بقیه جلسات (' + faDigits(total - saved) + ')' : 'ذخیره همه جلسات (' + faDigits(total) + ')', false);
    courseBar.status.textContent = faDigits(saved) + ' از ' + faDigits(total) + ' جلسه برای تماشای آفلاین ذخیره شده است';
  }

  // ---------- discovery ----------
  function diagnostics() {
    var vids = document.querySelectorAll('video');
    var lines = ['bridge v' + BRIDGE_VERSION, 'page: ' + location.pathname, 'videos: ' + vids.length,
      'lessons(.course-lesson): ' + document.querySelectorAll(S.lesson).length,
      'media boxes(.sc_le_vi_au): ' + document.querySelectorAll('.sc_le_vi_au').length,
      'bars: ' + bars.length, 'iframes: ' + document.querySelectorAll('iframe').length];
    for (var i = 0; i < vids.length && i < 8; i++) {
      var src = rawSources(vids[i])[0] || '';
      var a = absolute(src) || '';
      var host = a ? a.split('/')[2] || '' : (src ? 'relative' : 'none');
      var ext = (a.split('?')[0].match(/\.([a-z0-9]{2,5})$/i) || [])[1] || (a.indexOf('blob:') === 0 ? 'blob' : '?');
      lines.push('video ' + (i + 1) + ': host=' + host + ' ext=' + ext + ' matched=' + (VIDEO_RE.test(a) ? 'yes' : 'no') +
        ' class=' + cleanText(vids[i].className).slice(0, 60));
    }
    return lines.join('\n');
  }

  function scan() {
    try {
      var videos = document.querySelectorAll('video');
      for (var i = 0; i < videos.length; i++) attach(videos[i]);
      // Drop bars whose video left the page (popups), re-place the others.
      bars = bars.filter(function (e) {
        if (document.contains(e.video)) { place(e); return true; }
        if (e.bar.parentNode) e.bar.parentNode.removeChild(e.bar);
        return false;
      });
      ensureCourseBar();
      var items = bars.slice(0, MAX_ITEMS).map(function (e) { return infoFor(e.video, e.src); });
      var key = items.map(function (x) { return x.src; }).join('|');
      if (key !== reported) { reported = key; post({ type: 'videos', items: items }); }

      var course = courseStructure();
      if (course) {
        var ckey = JSON.stringify(course.sections);
        if (ckey !== reportedCourse) { reportedCourse = ckey; post(course); }
      }
      var meta = document.querySelector('meta[name="shipaa-app-sync"]');
      if (meta && meta.content && !scan.nonceSent) { scan.nonceSent = true; post({ type: 'syncNonce', nonce: meta.content }); }
      var d = diagnostics();
      if (d !== reportedDiag) { reportedDiag = d; post({ type: 'diag', text: d }); }
    } catch (e) {
      post({ type: 'diag', text: 'bridge v' + BRIDGE_VERSION + ' error: ' + (e && e.message) });
    }
  }

  var scheduled = false;
  function scheduleScan() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(function () { scheduled = false; scan(); }, 250);
  }

  // Videos whose source is set later (lazy players) report via loadedmetadata.
  document.addEventListener('loadedmetadata', function (ev) {
    if (ev.target && ev.target.tagName === 'VIDEO') scheduleScan();
  }, true);

  // ---------- back button ----------
  function handleBack() {
    try {
      for (var i = 0; i < BACK_CLOSERS.length; i++) {
        var el = document.querySelector(BACK_CLOSERS[i]);
        if (el && el.offsetParent !== null) { el.click(); return true; }
      }
      var fs = document.fullscreenElement || document.webkitFullscreenElement;
      if (fs) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return true; }
      var expanded = document.querySelector('[aria-expanded="true"][aria-controls]');
      if (expanded && expanded.offsetParent !== null) { expanded.click(); return true; }
    } catch (e) { /* fall through to history back */ }
    return false;
  }

  // ---------- native → page ----------
  function onNative(msg) {
    try {
      if (typeof msg === 'string') msg = JSON.parse(msg);
      if (!msg || !msg.type) return;
      if (msg.type === 'state' && msg.items) {
        for (var i = 0; i < msg.items.length; i++) {
          var it = msg.items[i];
          if (it && it.src) states[it.src] = it.state ? it : null;
        }
        bars.forEach(render);
        renderCourse();
      }
    } catch (e) { /* ignore */ }
  }

  window.ShipaaApp = { __ready: true, version: BRIDGE_VERSION, onNative: onNative, handleBack: handleBack, rescan: scan };

  function start() {
    ensureStyle();
    var font = '';
    try { font = getComputedStyle(document.body).fontFamily || ''; } catch (e) {}
    post({ type: 'hello', bridgeVersion: BRIDGE_VERSION, fontFamily: font.slice(0, 200) });
    scan();
    try {
      new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    } catch (e) {}
    // Players initialise after DOMContentLoaded; re-check placement once they are done.
    setTimeout(scan, 1200);
    setTimeout(scan, 4000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
