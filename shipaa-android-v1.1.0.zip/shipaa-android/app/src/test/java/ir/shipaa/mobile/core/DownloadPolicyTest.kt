package ir.shipaa.mobile.core

import ir.shipaa.mobile.core.download.ContentRange
import ir.shipaa.mobile.core.download.DownloadAction
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.download.DownloadStateMachine
import ir.shipaa.mobile.core.download.RangeDecision
import ir.shipaa.mobile.core.download.RangeResponsePolicy
import ir.shipaa.mobile.core.download.StatusTone
import ir.shipaa.mobile.core.download.StoragePolicy
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

class DownloadPolicyTest {
    @Test fun parsesContentRange() {
        assertEquals(ContentRange(0, 0, 500), ContentRange.parse("bytes 0-0/500"))
        assertEquals(ContentRange(100, 499, 500), ContentRange.parse("Bytes 100-499/500"))
        assertNull(ContentRange.parse("bytes 0-0/*"))
        assertNull(ContentRange.parse("bytes 5-4/10"))
        assertNull(ContentRange.parse("bytes 0-10/10"))
        assertNull(ContentRange.parse(null))
    }

    @Test fun resumeAppendsAtRequestedOffset() {
        val d = RangeResponsePolicy.decide(206, "bytes 1000-4999/5000", 4000, 1000, 5000)
        assertEquals(RangeDecision.Append(1000, 5000), d)
    }

    @Test fun rangeMismatchesAreRejectedOrRestarted() {
        assertIs<RangeDecision.Fail>(RangeResponsePolicy.decide(206, "bytes 0-4999/5000", null, 1000, 5000))
        assertIs<RangeDecision.Fail>(RangeResponsePolicy.decide(206, "bytes 1000-1999/5000", null, 1000, 5000))
        assertIs<RangeDecision.Fail>(RangeResponsePolicy.decide(206, "bytes 1000-4999/5000", 10, 1000, 5000))
        // Same offset, but the file on the server has a different size: start over.
        assertEquals(RangeDecision.Restart(6000), RangeResponsePolicy.decide(206, "bytes 1000-5999/6000", null, 1000, 5000))
    }

    @Test fun fullBodyMeansRestart() {
        assertEquals(RangeDecision.Restart(5000), RangeResponsePolicy.decide(200, null, 5000, 1000, 5000))
        assertEquals(RangeDecision.Restart(null), RangeResponsePolicy.decide(200, null, -1, 0, null))
    }

    @Test fun httpErrorsMapToErrors() {
        assertEquals(RangeDecision.AlreadyComplete, RangeResponsePolicy.decide(416, null, null, 5000, 5000))
        assertEquals(RangeDecision.Fail(DownloadError.SESSION_EXPIRED), RangeResponsePolicy.decide(403, null, null, 0, null))
        assertEquals(RangeDecision.Fail(DownloadError.NOT_FOUND), RangeResponsePolicy.decide(404, null, null, 0, null))
        assertEquals(RangeDecision.Fail(DownloadError.SERVER), RangeResponsePolicy.decide(503, null, null, 0, null))
        assertTrue(DownloadError.SERVER.retryable)
        assertTrue(!DownloadError.NO_SPACE.retryable)
    }

    @Test fun stateMachineHappyPath() {
        var s = DownloadState.QUEUED
        s = DownloadStateMachine.next(s, DownloadAction.START); assertEquals(DownloadState.DOWNLOADING, s)
        s = DownloadStateMachine.next(s, DownloadAction.NETWORK_LOST); assertEquals(DownloadState.WAITING_NETWORK, s)
        s = DownloadStateMachine.next(s, DownloadAction.START); assertEquals(DownloadState.DOWNLOADING, s)
        s = DownloadStateMachine.next(s, DownloadAction.COMPLETE); assertEquals(DownloadState.COMPLETED, s)
        s = DownloadStateMachine.next(s, DownloadAction.LICENSE_EXPIRED); assertEquals(DownloadState.NEEDS_VERIFICATION, s)
        s = DownloadStateMachine.next(s, DownloadAction.VERIFIED); assertEquals(DownloadState.COMPLETED, s)
    }

    @Test fun lateCallbacksDoNotResurrectPausedDownload() {
        val paused = DownloadStateMachine.next(DownloadState.DOWNLOADING, DownloadAction.PAUSE)
        assertEquals(DownloadState.PAUSED, paused)
        assertEquals(DownloadState.PAUSED, DownloadStateMachine.next(paused, DownloadAction.PROGRESS))
        assertEquals(DownloadState.PAUSED, DownloadStateMachine.next(paused, DownloadAction.COMPLETE))
        assertEquals(DownloadState.PAUSED, DownloadStateMachine.next(paused, DownloadAction.FAIL))
        assertEquals(DownloadState.QUEUED, DownloadStateMachine.next(paused, DownloadAction.RESUME))
        // A completed video is never re-queued by a stray enqueue.
        assertEquals(DownloadState.COMPLETED, DownloadStateMachine.next(DownloadState.COMPLETED, DownloadAction.ENQUEUE))
    }

    @Test fun lockingOnlyAffectsStoredVideos() {
        assertEquals(DownloadState.LOCKED, DownloadStateMachine.next(DownloadState.COMPLETED, DownloadAction.LOCK))
        assertEquals(DownloadState.NEEDS_VERIFICATION, DownloadStateMachine.next(DownloadState.LOCKED, DownloadAction.UNLOCK))
        assertEquals(DownloadState.PAUSED, DownloadStateMachine.next(DownloadState.PAUSED, DownloadAction.LOCK))
    }

    @Test fun everyStateHasDistinctPresentation() {
        val p = DownloadState.entries.map { DownloadPresentation.of(it) }
        assertEquals(p.size, p.map { it.label }.toSet().size, "labels must differ")
        assertEquals(StatusTone.SUCCESS, DownloadPresentation.of(DownloadState.COMPLETED).tone)
        assertEquals(StatusTone.PROGRESS, DownloadPresentation.of(DownloadState.DOWNLOADING).tone)
        assertEquals(StatusTone.WARNING, DownloadPresentation.of(DownloadState.PAUSED).tone)
        assertEquals(StatusTone.DANGER, DownloadPresentation.of(DownloadState.FAILED).tone)
        assertEquals(DownloadState.FAILED, DownloadState.parse("garbage"))
        assertTrue(DownloadPresentation.of(DownloadState.WAITING_NETWORK, DownloadError.SERVER).label.contains("سرور"))
        assertTrue(DownloadPresentation.of(DownloadState.LOCKED, DownloadError.ACCESS_REVOKED).label.contains("دسترسی"))
        // Every error has its own wording.
        assertEquals(DownloadError.entries.size, DownloadError.entries.map { DownloadPresentation.errorLabel(it) }.toSet().size)
    }

    @Test fun percentNeverShows100Early() {
        assertEquals(99, DownloadPresentation.percent(999, 1000, false))
        assertEquals(100, DownloadPresentation.percent(999, 1000, true))
        assertEquals(0, DownloadPresentation.percent(5, 0, false))
        assertEquals(50, DownloadPresentation.percent(5_000_000_000, 10_000_000_000, false))
    }

    @Test fun storageCheck() {
        val mb = 1024L * 1024
        assertEquals(StoragePolicy.Check.Ok, StoragePolicy.check(500 * mb, 100 * mb, 700 * mb))
        assertIs<StoragePolicy.Check.NotEnoughSpace>(StoragePolicy.check(500 * mb, 100 * mb, 500 * mb))
        assertEquals(StoragePolicy.Check.TooLarge, StoragePolicy.check(9L * 1024 * mb, 0, Long.MAX_VALUE))
        assertEquals(StoragePolicy.Check.Ok, StoragePolicy.check(null, 0, 300 * mb))
    }
}
