package ir.shipaa.mobile.core

import ir.shipaa.mobile.core.bridge.BridgeMessage
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.identity.WpIdentity
import ir.shipaa.mobile.core.license.AccessCheck
import ir.shipaa.mobile.core.license.LessonAccessVerifier
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.core.nav.NavigationPolicy
import ir.shipaa.mobile.core.nav.NavigationPolicy.Decision
import ir.shipaa.mobile.core.progress.ProgressPolicy
import ir.shipaa.mobile.core.progress.WatchProgress
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.core.update.UpdateDecision
import ir.shipaa.mobile.core.update.UpdateManifest
import ir.shipaa.mobile.core.update.UpdatePolicy
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PolicyTest {
    private val day = 86_400_000L

    @Test fun videoUrls() {
        assertEquals("https://dl.shipaa.ir/c/1/a.mp4", VideoUrlPolicy.normalize(" https://DL.shipaa.ir/c/1/a.mp4#t=3 "))
        assertEquals("https://dl.shipaa.ir/a.M4V?x=1", VideoUrlPolicy.normalize("https://dl.shipaa.ir/a.M4V?x=1"))
        listOf(
            "http://dl.shipaa.ir/a.mp4", "https://evil.ir/a.mp4", "https://dl.shipaa.ir.evil.ir/a.mp4",
            "https://user@dl.shipaa.ir/a.mp4", "https://dl.shipaa.ir:8443/a.mp4", "https://dl.shipaa.ir/a.mp3",
            "https://dl.shipaa.ir/../a.mp4", "javascript:alert(1)//a.mp4", "", "https://dl.shipaa.ir/" + "a".repeat(3000) + ".mp4",
        ).forEach { assertNull(VideoUrlPolicy.normalize(it), it) }
        val k1 = VideoUrlPolicy.keyOf("https://dl.shipaa.ir/a.mp4?token=1")
        assertEquals(k1, VideoUrlPolicy.keyOf("https://dl.shipaa.ir/a.mp4?token=2"))
        assertNotEquals(k1, VideoUrlPolicy.keyOf("https://dl.shipaa.ir/b.mp4"))
        assertEquals(32, k1.length)
        assertEquals("جلسه 01 مقدمه", VideoUrlPolicy.fallbackTitle("https://dl.shipaa.ir/x/%D8%AC%D9%84%D8%B3%D9%87_01-%D9%85%D9%82%D8%AF%D9%85%D9%87.mp4"))
    }

    @Test fun navigation() {
        val isVideo: (String) -> Boolean = { VideoUrlPolicy.isAllowed(it) }
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://shipaa.ir/my-account/", isVideo))
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://www.shipaa.ir/x", isVideo))
        assertEquals(Decision.InApp, NavigationPolicy.decide("http://shipaa.ir/x", isVideo))
        assertEquals(Decision.OpenLibrary, NavigationPolicy.decide("https://shipaa.ir/#shipaa-library", isVideo))
        assertEquals(Decision.OpenLibrary, NavigationPolicy.decide("shipaa://library", isVideo))
        assertIs<Decision.PlayNative>(NavigationPolicy.decide("https://dl.shipaa.ir/a.mp4", isVideo))
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://www.zarinpal.com/pg/x", isVideo))
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://sadad.shaparak.ir/Purchase", isVideo))
        assertIs<Decision.External>(NavigationPolicy.decide("https://notshaparak.ir/x", isVideo))
        assertIs<Decision.External>(NavigationPolicy.decide("https://instagram.com/shipaa", isVideo))
        // Payment redirect from checkout, and navigation inside the gateway, stay in the app.
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://sep.shaparak.ir/pay", isVideo, userGesture = false))
        assertEquals(Decision.InApp, NavigationPolicy.decide("https://bank.example/ok", isVideo, userGesture = true, fromSitePage = false))
        // Unsafe schemes are blocked even from redirects.
        assertEquals(Decision.Block, NavigationPolicy.decide("javascript:alert(1)", isVideo, userGesture = false))
        assertIs<Decision.External>(NavigationPolicy.decide("tel:+98912", isVideo))
        assertIs<Decision.External>(NavigationPolicy.decide("eitaa://x", isVideo))
        listOf("javascript:alert(1)", "file:///sdcard/x", "intent://x#Intent;end", "content://a", "data:text/html,x", null, "")
            .forEach { assertEquals(Decision.Block, NavigationPolicy.decide(it, isVideo), it.toString()) }
    }

    @Test fun identityFromWordPressCookie() {
        val now = 1_800_000_000L
        val header = "wp_woocommerce_session_x=1; wordpress_logged_in_abc=taha%7C1900000000%7Ctok%7Chmac; other=2"
        val id = assertNotNull(WpIdentity.fromCookieHeader(header, now))
        assertEquals("taha", id.username)
        assertEquals(24, id.ownerKey.length)
        assertEquals(id.ownerKey, WpIdentity("TAHA", 1).ownerKey)
        assertNull(WpIdentity.fromCookieHeader("wordpress_logged_in_abc=taha%7C1000%7Ct%7Ch", now), "expired")
        assertNull(WpIdentity.fromCookieHeader("wordpress_logged_in_abc=broken", now))
        assertNull(WpIdentity.fromCookieHeader(null, now))
    }

    @Test fun licence() {
        val p = LicensePolicy()
        val t0 = 1_700_000_000_000L
        assertEquals(LicensePolicy.Verdict.VALID, p.evaluate(t0 + day, t0, t0 + day))
        assertEquals(LicensePolicy.Verdict.VALID_REFRESH_SOON, p.evaluate(t0 + 5 * day, t0, t0 + 5 * day))
        assertEquals(LicensePolicy.Verdict.EXPIRED, p.evaluate(t0 + 31 * day, t0, t0 + 31 * day))
        // User turns the clock back to extend the licence.
        assertEquals(LicensePolicy.Verdict.CLOCK_TAMPERED, p.evaluate(t0 + day, t0, t0 + 40 * day))
        assertEquals(LicensePolicy.Verdict.CLOCK_TAMPERED, p.evaluate(t0 - 2 * day, t0, t0))
        // Small drift (time zone / NTP correction) is tolerated.
        assertEquals(LicensePolicy.Verdict.VALID, p.evaluate(t0 + day, t0, t0 + day + 3_600_000))
        assertEquals(t0 + day, p.advanceLastSeen(t0 + day, t0))
    }

    @Test fun lessonAccess() {
        val v = "https://dl.shipaa.ir/courses/x/lesson-01.mp4"
        val ok = """<div class="studi-player"><video src="https://dl.shipaa.ir/courses/x/lesson-01.mp4"></video></div>"""
        assertEquals(AccessCheck.GRANTED, LessonAccessVerifier.decide(200, "https://shipaa.ir/lesson/1", ok, v))
        val escaped = """{"lesson_video":"https:\/\/dl.shipaa.ir\/courses\/x\/lesson-01.mp4"}"""
        assertEquals(AccessCheck.GRANTED, LessonAccessVerifier.decide(200, "https://shipaa.ir/lesson/1", escaped, v))
        val login = """<form class="woocommerce-form-login"><input name="password"></form>"""
        assertEquals(AccessCheck.LOGGED_OUT, LessonAccessVerifier.decide(200, "https://shipaa.ir/my-account/", login, v))
        assertEquals(AccessCheck.UNKNOWN, LessonAccessVerifier.decide(200, "https://shipaa.ir/lesson/1", "<p>خرید کنید</p>", v))
        assertEquals(AccessCheck.REVOKED, LessonAccessVerifier.decide(404, "https://shipaa.ir/lesson/1", "", v))
        assertEquals(AccessCheck.REVOKED, LessonAccessVerifier.decide(403, "https://shipaa.ir/lesson/1", "", v))
        assertEquals(AccessCheck.UNKNOWN, LessonAccessVerifier.decide(502, "https://shipaa.ir/lesson/1", "", v))
    }

    @Test fun progress() {
        assertEquals(0, ProgressPolicy.resumePosition(null))
        assertEquals(0, ProgressPolicy.resumePosition(WatchProgress("k", 3_000, 600_000, 1)))
        assertEquals(120_000, ProgressPolicy.resumePosition(WatchProgress("k", 120_000, 600_000, 1)))
        assertEquals(0, ProgressPolicy.resumePosition(WatchProgress("k", 590_000, 600_000, 1)))
        val a = WatchProgress("k", 100, 1000, 10)
        val b = WatchProgress("k", 50, 1000, 20)
        assertEquals(b, ProgressPolicy.merge(a, b))
        assertEquals(a, ProgressPolicy.merge(a, b.copy(updatedAt = 5)))
        assertEquals(a, ProgressPolicy.merge(a, a.copy(positionMs = 10)))
        assertEquals(a, ProgressPolicy.merge(a, null))
        assertEquals(0.1f, a.fraction)
    }

    @Test fun updates() {
        val m = UpdateManifest(10203, 10100, "1.2.3", "https://shipaa.ir/app", "")
        assertIs<UpdateDecision.Optional>(UpdatePolicy.decide(10000 + 100, m))
        assertIs<UpdateDecision.Required>(UpdatePolicy.decide(10000, m))
        assertEquals(UpdateDecision.UpToDate, UpdatePolicy.decide(10203, m))
        assertEquals(UpdateDecision.UpToDate, UpdatePolicy.decide(10100, m, dismissedVersionCode = 10203))
        assertEquals(UpdateDecision.UpToDate, UpdatePolicy.decide(1, m.copy(downloadUrl = "http://x")))
        assertEquals(10203, UpdatePolicy.versionCodeOf("1.2.3"))
        assertEquals(10000, UpdatePolicy.versionCodeOf("1.0.0-rc1"))
    }

    @Test fun persianFormatting() {
        assertEquals("۱۲۳", PersianFormat.number(123))
        assertEquals("۱٫۵ گیگابایت", PersianFormat.bytes(1536L * 1024 * 1024))
        assertEquals("۳۴۰ مگابایت", PersianFormat.bytes(340L * 1024 * 1024))
        assertEquals("۲٫۵ مگابایت", PersianFormat.bytes(2560L * 1024))
        assertEquals("۱:۰۵:۰۹", PersianFormat.duration(3_909_000))
        assertEquals("۱۲:۰۴", PersianFormat.duration(724_000))
        assertEquals("۴۵٪", PersianFormat.percent(45))
    }

    @Test fun designTokensCss() {
        val css = DesignTokens.toCss()
        assertTrue(css.startsWith(":root{") && css.endsWith("}"))
        assertTrue(css.contains("--shp-primary:#136B4B;"))
        assertTrue(css.contains("--shp-r-panel:18px;"))
        assertEquals("#F5FAF6", DesignTokens.hex(DesignTokens.Color.background))
    }

    @Test fun bridgeMessagesAreValidated() {
        val page = "https://shipaa.ir/lesson/intro/"
        val play = BridgeMessage.from("play", mapOf("src" to "https://dl.shipaa.ir/a.mp4", "title" to "  جلسه\n اول ", "lessonId" to "4821"), page)
        play as BridgeMessage.Play
        assertEquals("جلسه اول", play.video.title)
        assertEquals(4821L, play.video.lessonId)
        assertEquals(page, play.video.pageUrl)
        assertNull(BridgeMessage.from("play", mapOf("src" to "https://evil.ir/a.mp4"), page))
        assertNull(BridgeMessage.from("exec", mapOf(), page))
        assertNull(BridgeMessage.from("syncNonce", mapOf("nonce" to "<script>"), page))
        val evilPage = BridgeMessage.from("download", mapOf("src" to "https://dl.shipaa.ir/a.mp4", "pageUrl" to "https://evil.ir/"), null) as BridgeMessage.Download
        assertEquals("", evilPage.video.pageUrl)
        val list = BridgeMessage.from("videos", mapOf("items" to List(400) { mapOf("src" to "https://dl.shipaa.ir/v$it.mp4") }), page) as BridgeMessage.Videos
        assertEquals(BridgeMessage.MAX_ITEMS, list.items.size)
        assertEquals(BridgeMessage.OpenLibrary, BridgeMessage.from("openLibrary", emptyMap(), page))
    }
}
