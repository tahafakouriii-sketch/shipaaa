package ir.shipaa.mobile.core

import ir.shipaa.mobile.core.bridge.BridgeMessage
import ir.shipaa.mobile.core.course.CourseInfo
import ir.shipaa.mobile.core.course.CourseOffline
import ir.shipaa.mobile.core.download.DownloadState
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CourseModelTest {
    private val page = "https://shipaa.ir/product/bazgasht/"
    private fun lesson(t: String, src: String?, locked: Boolean = false, quiz: Boolean = false) =
        mapOf("title" to t, "subtitle" to "", "badge" to "ویدیو", "number" to "1", "src" to src, "locked" to locked, "quiz" to quiz)

    // Same shape bridge.js sends for the Studiare course page.
    private val fields: Map<String, Any?> = mapOf(
        "type" to "course", "postId" to 777, "title" to "  دوره   بازگشت به قدرت ", "pageUrl" to page,
        "image" to "https://shipaa.ir/c.jpg",
        "sections" to listOf(
            mapOf("title" to "مقدمات", "label" to "فصل", "number" to "۱", "lessons" to listOf(
                lesson("جلسه اول", "https://dl.shipaa.ir/q/01.mp4"),
                lesson("جلسه دوم", "https://dl.shipaa.ir/q/02.mp4"),
                lesson("آزمون", null, quiz = true),
            )),
            mapOf("title" to "تمرین‌ها", "label" to "فصل", "number" to "۲", "lessons" to listOf(
                lesson("قفل", null, locked = true),
                lesson("بد", "https://evil.ir/x.mp4"),
                mapOf("subtitle" to "بدون عنوان"),
            )),
            mapOf("title" to "خالی", "lessons" to emptyList<Any>()),
        ),
    )

    @Test fun parsesAndValidatesTheCurriculum() {
        val msg = BridgeMessage.from("course", fields, page)
        assertIs<BridgeMessage.Course>(msg)
        val c = msg.course
        assertEquals(777L, c.postId)
        assertEquals("دوره بازگشت به قدرت", c.title)
        assertEquals(2, c.sections.size, "empty sections dropped")
        assertEquals(listOf("جلسه اول", "جلسه دوم", "آزمون", "قفل", "بد"), c.lessons.map { it.title }, "lessons without a title dropped")
        assertNull(c.lessons[4].src, "foreign video hosts rejected")
        assertEquals(listOf("https://dl.shipaa.ir/q/01.mp4", "https://dl.shipaa.ir/q/02.mp4"), c.videoSrcs)
        assertTrue(c.lessons[2].quiz)
        assertTrue(c.lessons[3].locked)
    }

    @Test fun rejectsForeignPagesAndCoursesWithoutAccess() {
        assertNull(BridgeMessage.from("course", fields + ("pageUrl" to "https://evil.ir/x"), "https://evil.ir/x"))
        val noAccess = fields + ("sections" to listOf(mapOf("title" to "s", "lessons" to listOf(lesson("قفل", null, locked = true)))))
        assertNull(BridgeMessage.from("course", noAccess, page), "nothing watchable: not stored")
    }

    @Test fun roundTripsThroughStorageMap() {
        val c = assertNotNull(CourseInfo.from(fields, page, now = 1234))
        assertEquals(1234, c.savedAt)
        val again = assertNotNull(CourseInfo.from(c.toMap(), null))
        assertEquals(c, again)
    }

    @Test fun keyIgnoresQueryAndFragment() {
        assertEquals(CourseInfo.keyOf(page), CourseInfo.keyOf("$page?tab=lessons#x"))
        assertEquals(CourseInfo.keyOf(page), CourseInfo.keyOf(page.trimEnd('/')))
        assertNotEquals(CourseInfo.keyOf(page), CourseInfo.keyOf("https://shipaa.ir/product/other/"))
    }

    @Test fun offlineSummary() {
        val c = assertNotNull(CourseInfo.from(fields, page))
        val states = mapOf("https://dl.shipaa.ir/q/01.mp4" to DownloadState.COMPLETED, "https://dl.shipaa.ir/q/02.mp4" to DownloadState.DOWNLOADING)
        val s = CourseOffline.summary(c) { states[it] }
        assertEquals(2, s.videoLessons)
        assertEquals(1, s.saved)
        assertEquals(1, s.downloading)
        assertEquals(0.5f, s.fraction)
        assertTrue(!s.complete)
        assertTrue(CourseOffline.summary(c) { DownloadState.COMPLETED }.complete)
    }

    @Test fun downloadAllAndDiagMessages() {
        val all = BridgeMessage.from("downloadAll", mapOf("items" to listOf(
            mapOf("src" to "https://dl.shipaa.ir/q/01.mp4", "title" to "جلسه اول"),
            mapOf("src" to "https://dl.shipaa.ir/q/01.mp4"),
            mapOf("src" to "https://evil.ir/x.mp4"),
        )), page)
        assertIs<BridgeMessage.DownloadAll>(all)
        assertEquals(1, all.items.size)
        assertNull(BridgeMessage.from("downloadAll", mapOf("items" to emptyList<Any>()), page))
        val diag = BridgeMessage.from("diag", mapOf("text" to "x".repeat(9000)), page)
        assertIs<BridgeMessage.Diag>(diag)
        assertEquals(4000, diag.text.length)
    }
}
