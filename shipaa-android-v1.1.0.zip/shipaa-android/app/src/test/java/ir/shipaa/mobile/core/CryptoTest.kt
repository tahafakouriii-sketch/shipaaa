package ir.shipaa.mobile.core

import ir.shipaa.mobile.core.crypto.CtrStreamCipher
import ir.shipaa.mobile.core.crypto.EncryptedVideoFile
import org.junit.Test
import java.io.File
import java.util.Random
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse

class CryptoTest {
    private val key = ByteArray(32) { it.toByte() }
    private val nonce = ByteArray(8) { (100 + it).toByte() }

    private fun plain(size: Int, seed: Long = 7): ByteArray = ByteArray(size).also { Random(seed).nextBytes(it) }

    @Test fun ctrRoundTripAtEveryAlignment() {
        val c = CtrStreamCipher(key, nonce)
        val data = plain(4099)
        val enc = data.copyOf().also { c.at(0).transform(it, 0, it.size) }
        assertFalse(enc.contentEquals(data))
        for (start in listOf(0, 1, 15, 16, 17, 31, 1000, 4098)) {
            val slice = enc.copyOfRange(start, enc.size)
            c.at(start.toLong()).transform(slice, 0, slice.size)
            assertContentEquals(data.copyOfRange(start, data.size), slice, "offset $start")
        }
    }

    @Test fun counterCarriesAcrossLowByte() {
        // Block index 256 needs a carry into the second-lowest IV byte.
        val c = CtrStreamCipher(key, nonce)
        val data = plain(16 * 300)
        val enc = data.copyOf().also { c.at(0).transform(it, 0, it.size) }
        val pos = 16 * 256 + 3
        val part = enc.copyOfRange(pos, pos + 50)
        c.at(pos.toLong()).transform(part, 0, part.size)
        assertContentEquals(data.copyOfRange(pos, pos + 50), part)
    }

    @Test fun rejectsBadKeySizes() {
        assertFailsWith<IllegalArgumentException> { CtrStreamCipher(ByteArray(16), nonce) }
        assertFailsWith<IllegalArgumentException> { CtrStreamCipher(key, ByteArray(12)) }
    }

    @Test fun encryptedFileResumesAndSeeks() {
        val f = File.createTempFile("shp", ".bin").apply { deleteOnExit() }
        val video = EncryptedVideoFile(f, CtrStreamCipher(key, nonce))
        video.truncate()
        val data = plain(300_000)
        // Simulate an interrupted download: three separate appenders, uneven chunk sizes.
        listOf(0 to 70_001, 70_001 to 200_000, 200_000 to 300_000).forEach { (a, b) ->
            video.appender().use { w -> assertEquals(a.toLong(), w.offset); w.write(data, a, b - a); w.sync() }
        }
        assertEquals(300_000L, video.length)
        // Ciphertext on disk must not equal plaintext.
        assertFalse(f.readBytes().copyOfRange(0, 64).contentEquals(data.copyOfRange(0, 64)))
        video.reader().use { r ->
            val all = ByteArray(300_000)
            var n = 0
            while (n < all.size) { val k = r.read(all, n, 8191); if (k < 0) break; n += k }
            assertContentEquals(data, all)
            for (pos in listOf(299_999L, 12_345L, 0L, 70_001L)) {
                r.seek(pos)
                val buf = ByteArray(10)
                val k = r.read(buf, 0, 10)
                assertContentEquals(data.copyOfRange(pos.toInt(), pos.toInt() + k), buf.copyOf(k))
            }
            r.seek(300_000)
            assertEquals(-1, r.read(ByteArray(4), 0, 4))
        }
        video.truncate()
        assertEquals(0L, video.length)
    }

    @Test fun appenderDoesNotModifyCallerBuffer() {
        val f = File.createTempFile("shp", ".bin").apply { deleteOnExit() }
        val video = EncryptedVideoFile(f, CtrStreamCipher(key, nonce))
        video.truncate()
        val data = plain(1000)
        val copy = data.copyOf()
        video.appender().use { it.write(data, 0, data.size) }
        assertContentEquals(copy, data)
    }
}
